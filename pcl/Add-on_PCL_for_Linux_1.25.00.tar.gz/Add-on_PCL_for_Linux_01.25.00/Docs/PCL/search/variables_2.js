var searchData=
[
  ['dwproductnumber_468',['dwProductNumber',['../structspm_info__t.html#aae9f9003a48b1740ec251092a28eca71',1,'spmInfo_t']]],
  ['dwserialnumber_469',['dwSerialNumber',['../structspm_info__t.html#a619b72b1df69e0a5f2f7541eca6a7d13',1,'spmInfo_t']]]
];
