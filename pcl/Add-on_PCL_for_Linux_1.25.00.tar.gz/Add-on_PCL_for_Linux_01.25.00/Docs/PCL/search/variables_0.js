var searchData=
[
  ['adressip_465',['AdressIP',['../struct___i_p___c_o_m_p_a_n_i_o_n___i_n_f_o.html#a197b308b28efbcc13a42b9d2b49a42e5',1,'_IP_COMPANION_INFO']]],
  ['adressmac_466',['AdressMAC',['../struct___i_p___c_o_m_p_a_n_i_o_n___i_n_f_o.html#a24f48a6862b2183cb026e4c64e7e5d0c',1,'_IP_COMPANION_INFO']]]
];
