var searchData=
[
  ['isdirectory_471',['isDirectory',['../structtelium__file__t.html#a6ccd01fd44c1e4ee18ef931da9c12ac7',1,'telium_file_t']]]
];
