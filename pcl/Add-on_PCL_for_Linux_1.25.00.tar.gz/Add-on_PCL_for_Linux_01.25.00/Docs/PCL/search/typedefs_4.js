var searchData=
[
  ['endreceiptfunc_508',['EndReceiptFunc',['../pda_util_8h.html#a2ffc0cd3e1f10ab8e0087dd5fa8150d3',1,'pdaUtil.h']]]
];
