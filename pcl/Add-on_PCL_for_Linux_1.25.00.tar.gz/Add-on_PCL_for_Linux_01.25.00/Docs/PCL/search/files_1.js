var searchData=
[
  ['mainpage_2etxt_361',['mainpage.txt',['../mainpage_8txt.html',1,'']]]
];
