var searchData=
[
  ['socket_5ferror_696',['SOCKET_ERROR',['../pda_util_8h.html#a633b0396ff93d336a088412a190a5072',1,'pdaUtil.h']]],
  ['success_697',['SUCCESS',['../_pcl_utilities_8h.html#aa90cac659d18e8ef6294c7ae337f6b58',1,'PclUtilities.h']]]
];
