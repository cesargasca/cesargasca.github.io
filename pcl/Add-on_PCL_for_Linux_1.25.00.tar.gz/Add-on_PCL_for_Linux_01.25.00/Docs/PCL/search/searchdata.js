var indexSectionsWithContent =
{
  0: "_abcdefghilmnoprstuw",
  1: "_cist",
  2: "fmp",
  3: "abcdefgiloprst",
  4: "acdfinpsuw",
  5: "abcdefhilpsuw",
  6: "et",
  7: "afis",
  8: "abefimpst"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Macros"
};

