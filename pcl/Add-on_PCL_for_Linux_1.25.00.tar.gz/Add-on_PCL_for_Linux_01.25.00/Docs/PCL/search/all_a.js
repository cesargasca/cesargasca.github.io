var searchData=
[
  ['launchm2osshortcut_244',['launchM2OSShortcut',['../pda_util_8h.html#acee2d14e11356c1e07363ec32b5d936a',1,'pdaUtil.h']]],
  ['lpsystemtime_245',['LPSYSTEMTIME',['../pda_util_8h.html#a7ec46b8d31bb93b3365a79598d4ef352',1,'pdaUtil.h']]]
];
