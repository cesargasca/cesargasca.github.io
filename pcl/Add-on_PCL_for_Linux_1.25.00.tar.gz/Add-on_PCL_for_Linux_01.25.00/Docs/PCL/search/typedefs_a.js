var searchData=
[
  ['signcapfunc_523',['SignCapFunc',['../pda_util_8h.html#a1e9bc41e800564b411d37cf6d03e51c0',1,'pdaUtil.h']]],
  ['socket_524',['SOCKET',['../pda_util_8h.html#a8dc8083897335125630f1af5dafd5831',1,'pdaUtil.h']]],
  ['spmci_5fhandle_525',['SPMCI_HANDLE',['../pda_util_8h.html#a2c25f845ba9fdd4b90d7a7d65e46cb6c',1,'pdaUtil.h']]],
  ['startreceiptfunc_526',['StartReceiptFunc',['../pda_util_8h.html#a7dec4ac535d29c2bc62698a5b7b3ea35',1,'pdaUtil.h']]],
  ['systemtime_527',['SYSTEMTIME',['../pda_util_8h.html#a82a530fa04b141779c2d9d2d7dc2292e',1,'pdaUtil.h']]]
];
