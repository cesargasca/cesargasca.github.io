var searchData=
[
  ['invalid_5fsocket_693',['INVALID_SOCKET',['../pda_util_8h.html#a26769957ec1a2beaf223f33b66ee64ab',1,'pdaUtil.h']]]
];
