var searchData=
[
  ['file_5fsharing_5fstate_5fconnected_539',['FILE_SHARING_STATE_CONNECTED',['../file_sharing_8h.html#a61199477842044f96d695b44fa45467da46082102eeb500add45bf0b3b4888f26',1,'fileSharing.h']]],
  ['file_5fsharing_5fstate_5fconnecting_540',['FILE_SHARING_STATE_CONNECTING',['../file_sharing_8h.html#a61199477842044f96d695b44fa45467dacaa5bacbac6ccc610ccdb09486066a7b',1,'fileSharing.h']]],
  ['file_5fsharing_5fstate_5fdisconnected_541',['FILE_SHARING_STATE_DISCONNECTED',['../file_sharing_8h.html#a61199477842044f96d695b44fa45467da1e8c34067020298bb7c2bb2b7959a575',1,'fileSharing.h']]],
  ['file_5fsharing_5fstate_5fdisconnecting_542',['FILE_SHARING_STATE_DISCONNECTING',['../file_sharing_8h.html#a61199477842044f96d695b44fa45467da1d37c0057507eda44b23dc50b626ce61',1,'fileSharing.h']]]
];
