var searchData=
[
  ['handle_510',['HANDLE',['../pda_util_8h.html#aa8c0374618b33785ccb02f74bcfebc46',1,'pdaUtil.h']]]
];
