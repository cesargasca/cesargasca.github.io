var searchData=
[
  ['paddsignaturefunc_474',['pAddSignatureFunc',['../structcallbacks__t.html#a9cc0d08e165793cb9e0924005e27831b',1,'callbacks_t']]],
  ['path_475',['path',['../structtelium__file__t.html#ac449e1b178f33eb5a545d8e7dc8510a8',1,'telium_file_t']]],
  ['pbarcodeeventclosefunc_476',['pBarcodeEventCloseFunc',['../structcallbacks__t.html#a162bd1227042189248e63f5297c41574',1,'callbacks_t']]],
  ['pbarcodeeventextfunc_477',['pBarcodeEventExtFunc',['../structcallbacks__t.html#a81aca17a040f5404acb3eb9f1ad672d1',1,'callbacks_t']]],
  ['pbarcodeeventfunc_478',['pBarcodeEventFunc',['../structcallbacks__t.html#a7d27486ab5968d7c812438c40c5052f2',1,'callbacks_t']]],
  ['pcutpaperfunc_479',['pCutPaperFunc',['../structcallbacks__t.html#a8fdba96efc1dc9f2f9b18fa3e38a1d94',1,'callbacks_t']]],
  ['pendreceiptfunc_480',['pEndReceiptFunc',['../structcallbacks__t.html#a4825fd19cd755057b4cdc9a720608d01',1,'callbacks_t']]],
  ['pfeedpaperfunc_481',['pFeedPaperFunc',['../structcallbacks__t.html#ab6294022f38136dffa48931023156776',1,'callbacks_t']]],
  ['pprintimagefunc_482',['pPrintImageFunc',['../structcallbacks__t.html#ab70d31779da63bc4408ab87ec7fae633',1,'callbacks_t']]],
  ['pprinttextfunc_483',['pPrintTextFunc',['../structcallbacks__t.html#ab21fb5e3c41e50e626f6521ae2b9808b',1,'callbacks_t']]],
  ['psigncapfunc_484',['pSignCapFunc',['../structcallbacks__t.html#a0f0f84fdec0d1ff59581b590fd5d81ca',1,'callbacks_t']]],
  ['pstartreceiptfunc_485',['pStartReceiptFunc',['../structcallbacks__t.html#ae50124f828263c5bd69e71df2424ebdf',1,'callbacks_t']]]
];
