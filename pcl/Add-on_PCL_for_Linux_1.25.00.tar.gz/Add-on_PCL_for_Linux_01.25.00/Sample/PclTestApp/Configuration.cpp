#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <vector>
#include "Configuration.h"

#include "pdaUtil.h"
#include<iostream>
#include<fstream>
#include "mstream.h"

using namespace std;

void getInfosCmd() {
	spmInfo_t infos;
	if(getTerminalInfo(&infos)){
		sout << "Product number: " << std::hex << infos.dwProductNumber << endl;
		sout << "Serial number: " << infos.dwSerialNumber << endl;
		sout.unsetf(ios::hex);
	} else {
		sout << "ERROR TO GET TERMINAL INFOS" << endl;
	}
}

void getTimeCmd() {
	SYSTEMTIME time;
	if(getTerminalTime(&time)){
		sout << "Terminal time: " << time.wHour << ":" << time.wMinute << ":" << time.wSecond << " " << time.wDay << "/" << time.wMonth << "/" << time.wYear << endl;
	} else {
		sout << "ERROR TO GET TERMINAL TIME" << endl;
	}
}

void setTimeCmd() {
	unsigned long int result;
	if(setTerminalTime(&result)){
		if(result == 0){
			sout << "SET TERMINAL TIME OK" << endl;
		} else {
			sout << "SET TERMINAL TIME KO" << endl;
		}
	} else {
		sout << "SET TERMINAL TIME KO" << endl;
	}
}

void shortcutCmd() {
	if(launchM2OSShortcut("13")){
		sout << "LAUNCH SHORTCUT OK" << endl;
	} else {
		sout << "LAUNCH SHORTCUT KO" << endl;
	}
}

void getFullSerialNumberCmd() {
	char fullSerial[128];

	if(getFullSerialNumber(fullSerial, sizeof(fullSerial))) {
		sout << "FullSerialNumber: " << fullSerial << endl;
	} else {
		sout << "GETFULLSERIALNUMBER KO" << endl;
	}
}

void resetCmd() {

	if(resetTerminal(0)) {
		sout << "RESET TERMINAL OK" << endl;
	} else {
		sout << "RESET TERMINAL KO" << endl;
	}
}

void getSPMCIVersionCmd(){
    char spmciVersion[5];

    if(getSpmciVersion(spmciVersion, sizeof(spmciVersion))){
    	sout << "SPMCI Version: " << spmciVersion << endl;
    } else {
    	sout << "GET SPMCI VERSION KO" << endl;
    }
}

void inputSimulCmd(){

    if(inputSimul("1")){
    	if(inputSimul("2")){
    		if(inputSimul("3")){
    			if(inputSimul("\x16")){
    				sout << "INPUT SIMUL OK" << endl;
				} else {
			    	sout << "INPUT SIMUL KO" << endl;
			    }
			} else {
		    	sout << "INPUT SIMUL KO" << endl;
		    }
		} else {
	    	sout << "INPUT SIMUL KO" << endl;
	    }
    } else {
    	sout << "INPUT SIMUL KO" << endl;
    }
}

void setLockBacklightCmd(int val){
	char result;

	BOOL resultB = setBacklightLock(val, &result);

	if(resultB && result == 0){
		sout << "SET LOCK BACKLIGHT OK" << endl;
	} else {
		sout << "SET LOCK BACKLIGHT KO" << endl;
	}
}

void getBatteryLevelCmd()
{
	int batLevel;
	BOOL resultB = getBatteryLevel(&batLevel);

	if(resultB){
		sout << "GET BATTERY LEVEL OK" << endl;
		sout << "Battery level: " << batLevel << endl;
	} else {
		sout << "GET BATTERY LEVEL KO" << endl;
	}
}

void getTerminalComponentCmd(){
	char *fileCompInfos = "/tmp/componants.lst";
	bool result = getTerminalComponents(fileCompInfos);
	if(result){
		ifstream file(fileCompInfos);
		string str;
		string file_contents;
		while (getline(file, str))
		{
			file_contents += str;
			file_contents.push_back('\n');
		}
		const char * c = file_contents.c_str();
		sout << "Terminal components: " << c << endl;
	} else {
		sout << "GET TERMINAL COMPONENT KO" << endl;
	}
}
