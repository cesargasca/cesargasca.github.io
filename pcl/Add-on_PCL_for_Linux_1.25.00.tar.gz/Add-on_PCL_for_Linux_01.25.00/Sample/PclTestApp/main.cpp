#include <iostream>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <limits>
#include <vector>
#include "PclUtilities.h"
#include "pdaUtil.h"
#include "Configuration.h"
#include "Message.h"
#include "Transaction.h"
#include "TMS.h"
#include "Printer.h"
#include "Barcode.h"
#include "Network.h"
#include "Callbacks.h"
#include "LoopDialog.h"
#include "mstream.h"
using namespace std;

string getPPPStatusCmd();
void startServiceCmd();
void stopServiceCmd();
void PrintText(char* szText, unsigned char font, unsigned char justification, unsigned char xFactor, unsigned char yFactor, unsigned char underline, unsigned char bold,
    unsigned char charset);
void PrintImage(unsigned long width, unsigned long height, char* image, unsigned long size, unsigned char justification);
void FeedPaper(DWORD dwLines);
void CutPaper();
int StartReceipt(unsigned char type);
int EndReceipt();
void AddSignature();
int SignatureCapture(int width, int height, int, unsigned char* data, unsigned long* dataSize);
void BarcodeEventExt(char* data, int len, char* symb, int len_symb);
void BarcodeEvent(char* data, int len);
void BarcodeEventClose();
void displayMenu(int menu);
void actionsMAIN(int apiSelected);
void actionsINFO(int apiSelected);
void actionsADMIN(int apiSelected);
void actionsNETWORK(int apiSelected);
void actionsTRANSACTION(int apiSelected);
void actionsPRINTER(int apiSelected);
void actionsBARCODE(int apiSelected);
void actionsPARAMETERS(int apiSelected);
void actionsLOOPTEST(int apiSelected);

#define MENU_PARAMETERS 98
#define MENU_MAIN 99
#define MENU_INFO 2
#define MENU_ADMIN 3
#define MENU_NETWORK 4
#define MENU_TRANSACTION 5
#define MENU_PRINTER 6
#define MENU_BARCODE 7
#define MENU_LOOP_TEST 8

bool g_timeToQuit = false;
int g_currentMenu = MENU_MAIN;

std::vector<IP_COMPANION_INFO> g_IPCompanions;
PUSB_COMPANION_INFO pUsbCompanions = NULL;
PUSB_COMPANION_INFO pRs232Companions = NULL;
DWORD g_dwEntries = 0, g_dwEntriesRs232 = 0, g_dwEntriesUsb = 0, g_dwEntriesIP = 0;

static void clean_result_list()
{
    if (pUsbCompanions != NULL) {
        free(pUsbCompanions);
        pUsbCompanions = NULL;
    }
    if (pRs232Companions != NULL) {
        free(pRs232Companions);
        pRs232Companions = NULL;
    }
    g_dwEntries = 0;
    g_dwEntriesRs232 = 0;
    g_dwEntriesUsb = 0;
    g_dwEntriesIP = 0;
}


int main(int argc,char** argv)
{
    if((argc > 1)&&(argv[1] != NULL))
    {
        #define FILE_WRITING "FILE_WRITING=%d"
        #define FILE_WRITING_SIZE sizeof(FILE_WRITING)
        char arg1[FILE_WRITING_SIZE] = {0};
        int tmp = 0;
        strncpy(arg1,argv[1],FILE_WRITING_SIZE);
        if(sscanf(argv[1],FILE_WRITING,&tmp) > 0)
        {
            if(tmp == 1)
            {
                sout.coss.open("/tmp/pclTestApp.log");
            }
        }
    }

    int apiSelected = MENU_MAIN;
    char act_name[128];
    DWORD act_type = 0;

    callbacks_t callbacks = {
        (BarcodeEventFunc)&BarcodeEvent,
        (SignCapFunc)&SignatureCapture,
        (PrintTextFunc)&PrintText,
        (PrintImageFunc)&PrintImage,
        (FeedPaperFunc)&FeedPaper,
        (CutPaperFunc)&CutPaper,
        (StartReceiptFunc)&StartReceipt,
        (EndReceiptFunc)&EndReceipt,
        (AddSignatureFunc)&AddSignature,
        (BarcodeEventCloseFunc)&BarcodeEventClose,
        (BarcodeEventExtFunc)&BarcodeEventExt
    };
    registerCallback(callbacks);

    sout << "\033[2J\033[1;1H";
    sout << endl;
    if (getActivatedDevice(act_name, sizeof(act_name), &act_type) == SUCCESS) {
        sout << "Terminal " << act_name << ", type " << act_type << " Enable" << endl;
    } else {
        sout << "No terminal selected" << endl;
    }

    #ifdef USE_OPENSSL
    //init ssl files
	setRootCA("./cert_files/SPMCI_CA.CRT",strlen("./cert_files/SPMCI_CA.CRT"));
    setClientCertificate("./cert_files/pclTestApp.pem", strlen("./cert_files/pclTestApp.pem"));
    setClientKey("./cert_files/pclTestApp.key", strlen("./cert_files/pclTestApp.key"), "sdkpcl", strlen("sdkpcl"));
    setDHFile("./cert_files/dh1024.pem", strlen("./cert_files/dh1024.pem"));
    #endif
    displayMenu(apiSelected);

    while (g_timeToQuit != true) {
        sout << "Action to launch: " << endl;
        //cin >> apiSelected;

        while (!(cin >> apiSelected)) {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            sout << "Invalid input.  Try again: " << endl;
        }

        //Clear of console
        sout << "\033[2J\033[1;1H" << endl;

        switch (g_currentMenu) {
        case MENU_MAIN:
            actionsMAIN(apiSelected);
            break;
        case MENU_INFO:
            actionsINFO(apiSelected);
            break;
        case MENU_ADMIN:
            actionsADMIN(apiSelected);
            break;
        case MENU_NETWORK:
            actionsNETWORK(apiSelected);
            break;
        case MENU_TRANSACTION:
            actionsTRANSACTION(apiSelected);
            break;
        case MENU_PRINTER:
            actionsPRINTER(apiSelected);
            break;
        case MENU_BARCODE:
            actionsBARCODE(apiSelected);
            break;
        case MENU_PARAMETERS:
            actionsPARAMETERS(apiSelected);
            break;
        case MENU_LOOP_TEST:
            actionsLOOPTEST(apiSelected);
            break;
        case 1000: //Exit
            g_timeToQuit = true;
            break;
        default:
            sout << "This number doesn't exist in the list of available functions " << endl;
            displayMenu(MENU_MAIN);
            g_currentMenu = MENU_MAIN;
        }

        sout << "----> " << getPPPStatusCmd() << " <----" << endl;
    }
    clean_result_list();
    sout << "End of application " << endl;

    if(sout.coss.is_open())
    {
        sout.coss.close();
    }
    return 0;
}

void display_parameters_menu()
{
    DWORD dwRet = 0, dwSizeRs232 = 0, dwSizeUsb = 0;
    clean_result_list();
    sout << "Start Scan..." << endl;
    //Search USB Terminal
    dwRet = getUSBDevices(NULL, &dwSizeUsb, &g_dwEntriesUsb);
    if (dwRet == ERROR_NOT_ENOUGH_MEMORY && g_dwEntriesUsb > 0) {
        pUsbCompanions = (PUSB_COMPANION_INFO)malloc(dwSizeUsb);
        memset(pUsbCompanions, 0, dwSizeUsb);
        dwRet = getUSBDevices(pUsbCompanions, &dwSizeUsb, &g_dwEntriesUsb);

        if (dwRet == SUCCESS && g_dwEntriesUsb > 0) {
            for (int i = 0; i < (int)g_dwEntriesUsb; i++) {
                if (pUsbCompanions[i].fActivated == true) {
                    sout << i << " - " << pUsbCompanions[i].szPort << "(" << pUsbCompanions[i].szSymbPort << ")" << " : " << pUsbCompanions[i].szName << " Enabled" << endl;
                } else {
                    sout << i << " - " << pUsbCompanions[i].szPort << "(" << pUsbCompanions[i].szSymbPort << ")" << " : " << pUsbCompanions[i].szName << " Disabled" << endl;
                }
            }
            g_dwEntries = g_dwEntriesUsb;
        } else {
            sout << "No terminal connected on USB port" << endl;
        }
    }else {
        sout << "No terminal connected on USB port" << endl;
    }

    //Search RS232 terminal
    dwRet = getRS232Devices(NULL, &dwSizeRs232, &g_dwEntriesRs232);

    pRs232Companions = (PUSB_COMPANION_INFO)malloc(dwSizeRs232);
    memset(pRs232Companions, 0, dwSizeRs232);
    dwRet = getRS232Devices(pRs232Companions, &dwSizeRs232, &g_dwEntriesRs232);

    if (dwRet == SUCCESS && g_dwEntriesRs232 > 0) {

        for (int j = 0; j < (int)g_dwEntriesRs232; j++) {
            if (pRs232Companions[j].fActivated == true) {
                sout << j + g_dwEntries << " - " << pRs232Companions[j].szPort << " : " << pRs232Companions[j].szName << " Enabled" << endl;
            } else {
                sout << j + g_dwEntries << " - " << pRs232Companions[j].szPort << " : " << pRs232Companions[j].szName << " Disabled" << endl;
            }
        }
        g_dwEntries += g_dwEntriesRs232;
    } else {
        sout << "No terminal connected on RS232 port" << endl;
    }

    //Search IP terminal
    IP_COMPANION_INFO IPCompanionsTmp[32];
    DWORD dwSizeIP = sizeof(IPCompanionsTmp);
    memset(IPCompanionsTmp, 0, dwSizeIP);

    dwRet = getIPDevices(IPCompanionsTmp, &dwSizeIP, &g_dwEntriesIP);

    //Add new terminal in list if need
    if (dwRet == SUCCESS && g_dwEntriesIP > 0) {
        for (DWORD j = 0; j < g_dwEntriesIP; ++j) {
            bool found = false;
            for (auto it = g_IPCompanions.begin(); it != g_IPCompanions.end(); ++it) {
                if (strcmp((*it).szName, (IPCompanionsTmp[j]).szName) == 0) {
                    found = true;
                    (*it).fActivated = (IPCompanionsTmp[j]).fActivated;
                    (*it).UseSsl = (IPCompanionsTmp[j]).UseSsl;
                    break;
                }
            }

            if (!found)
                g_IPCompanions.push_back(IPCompanionsTmp[j]);
        }
    }

    if (g_IPCompanions.size() > 0) {
        int j = 0;
        for (auto it = g_IPCompanions.begin(); it != g_IPCompanions.end(); ++it) {
            if (it->fActivated == true) {
                sout << j + g_dwEntries << " - " << it->AdressIP << " : " << it->szName << " Enabled" << endl;
            } else {
                sout << j + g_dwEntries << " - " << it->AdressIP << " : " << it->szName << " Disabled" << endl;
            }
            ++j;
        }
        g_dwEntries += (DWORD)g_IPCompanions.size();
    } else {
        sout << "No terminal connected on network" << endl;
    }

    //No terminals connected
    if (g_dwEntries == 0) {
        sout << "No terminal found!!!" << endl;
    }

    sout << g_dwEntries << " - Rescan" << endl;
    sout << (g_dwEntries + 1) << " - Direct Connect" << endl;
    sout << (g_dwEntries + 2) << " - Quit" << endl;
    sout << "Choose an action or an terminal to use it: " << endl;
}

static void selectSslOption(PIP_COMPANION_INFO pTmpComp)
{
    char usessl;
    sout << "Use SSL [Y/n]" << endl;
    while (!(cin >> usessl)) {
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
        sout << "Invalid input.  Try again: " << endl;
    }

    if (usessl == 'Y') {
        pTmpComp->UseSsl = 1;
    } else {
        pTmpComp->UseSsl = 0;
    }
}

void actionsPARAMETERS(int apiSelected)
{
    if (apiSelected < (int)g_dwEntriesUsb) {
        stopPclService();
        if (pUsbCompanions) {
            if (pUsbCompanions[apiSelected].szSymbPort[0] != 0 || strlen(pUsbCompanions[apiSelected].szSymbPort) != 0) {
                activateUSBDevice(pUsbCompanions[apiSelected].szSymbPort);
            } else {
                activateUSBDevice(pUsbCompanions[apiSelected].szPort);
            }
        } else {
            sout << "pUsbCompanions == NULL" << endl;
        }
        sleep(2);
        displayMenu(MENU_MAIN);
    } else if (apiSelected < (int)(g_dwEntriesRs232 + g_dwEntriesUsb)) {
        stopPclService();
        if (pRs232Companions) {
            activateRS232Device(pRs232Companions[apiSelected - g_dwEntriesUsb].szPort);
        } else {
            sout << "pRs232Companions == NULL" << endl;
        }
        sleep(2);
        displayMenu(MENU_MAIN);
    } else if (apiSelected < (int)(g_dwEntriesRs232 + g_dwEntriesUsb + g_dwEntriesIP)) {
        stopPclService();
        PIP_COMPANION_INFO pTmpComp = &(g_IPCompanions.at(apiSelected - (g_dwEntriesUsb + g_dwEntriesRs232)));
        if (pTmpComp != NULL) {
            selectSslOption(pTmpComp);
            activateIPDevice(pTmpComp);
        } else {
            sout << "pIPCompanions == NULL" << endl;
        }
        sleep(2);
        displayMenu(MENU_MAIN);
    } else {
        if (apiSelected == (int)g_dwEntries) {
            //case rescan
            displayMenu(MENU_PARAMETERS);
        } else if (apiSelected == (int)(g_dwEntries + 1)) {
            stopPclService();

            //case direct connect
            IP_COMPANION_INFO dc_conf;
            memset(&dc_conf, 0, sizeof(IP_COMPANION_INFO));
            selectSslOption(&dc_conf);
            strcpy(dc_conf.AdressIP, "255.255.255.255");
            strcpy(dc_conf.AdressMAC, "FF:FF:FF:FF:FF:FF");
            strcpy(dc_conf.szName, "Direct_Connect");
            activateIPDevice(&dc_conf);
            sout << "Active Direct Connect mode" << endl;
            sleep(2);
            displayMenu(MENU_MAIN);
        } else {
            //case quit
            displayMenu(MENU_MAIN);
        }
    }
}

void actionsMAIN(int apiSelected)
{

    switch (apiSelected) {
    case 0:
        startServiceCmd();
        displayMenu(MENU_MAIN);
        break;
    case 1:
        stopServiceCmd();
        displayMenu(MENU_MAIN);
        break;
    case 2:
        displayMenu(MENU_INFO);
        break;
    case 3:
        displayMenu(MENU_ADMIN);
        break;
    case 4:
        displayMenu(MENU_NETWORK);
        break;
    case 5:
        displayMenu(MENU_TRANSACTION);
        break;
    case 6:
        displayMenu(MENU_PRINTER);
        break;
    case 7:
        displayMenu(MENU_BARCODE);
        break;
    case 8:
        displayMenu(MENU_LOOP_TEST);
        break;
    case 99:
        displayMenu(MENU_MAIN);
        break;
    case 998:
        displayMenu(MENU_PARAMETERS);
        break;
    case 999:
        displayMenu(MENU_MAIN);
        break;
    //Exit
    case 1000:
        g_timeToQuit = true;
        break;
    default:
        sout << "This number doesn't exist in the list of available functions " << endl;
        displayMenu(MENU_MAIN);
    }
}

void actionsINFO(int apiSelected)
{

    switch (apiSelected) {
    case 1:
        getInfosCmd();
        displayMenu(MENU_INFO);
        break;
    case 2:
        getTerminalComponentCmd();
        displayMenu(MENU_INFO);
        break;
    case 3:
        getFullSerialNumberCmd();
        displayMenu(MENU_INFO);
        break;
    case 4:
        getSPMCIVersionCmd();
        displayMenu(MENU_INFO);
        break;
    case 5:
        getBatteryLevelCmd();
        displayMenu(MENU_INFO);
        break;
    case 99:
        displayMenu(MENU_MAIN);
        break;
    default:
        sout << "This number doesn't exist in the list of available functions " << endl;
        displayMenu(MENU_INFO);
    }
}

void actionsADMIN(int apiSelected)
{

    switch (apiSelected) {
    case 1:
        getTimeCmd();
        displayMenu(MENU_ADMIN);
        break;
    case 2:
        setTimeCmd();
        displayMenu(MENU_ADMIN);
        break;
    case 3:
        resetCmd();
        displayMenu(MENU_ADMIN);
        break;
    case 4:
        inputSimulCmd();
        displayMenu(MENU_ADMIN);
        break;
    case 5:
        shortcutCmd();
        displayMenu(MENU_ADMIN);
        break;
    case 6:
        setLockBacklightCmd(3); 
        displayMenu(MENU_ADMIN);
        break;   
    case 7:
        setLockBacklightCmd(0);
        displayMenu(MENU_ADMIN);
        break;               
    case 99:
        displayMenu(MENU_MAIN);
        break;
    default:
        sout << "This number doesn't exist in the list of available functions " << endl;
        displayMenu(MENU_ADMIN);
    }
}

void actionsNETWORK(int apiSelected)
{

    switch (apiSelected) {
    case 1:
        sendMessageCmd();
        displayMenu(MENU_NETWORK);
        break;
    case 2:
        receiveMessageCmd();
        displayMenu(MENU_NETWORK);
        break;
    case 3:
        flushMessageCmd();
        displayMenu(MENU_NETWORK);
        break;
    case 4:
        doUpdateCmd();
        displayMenu(MENU_NETWORK);
        break;
    case 5:
        tmsReadParametersCmd();
        displayMenu(MENU_NETWORK);
        break;
    case 6:
        tmsWriteParametersT2Cmd();
        displayMenu(MENU_NETWORK);
        break;
    case 7:
        tmsWriteParametersT3Cmd();
        displayMenu(MENU_NETWORK);
        break;
    case 8:
        addDynamicBridgeFromTelliumCmd();
        displayMenu(MENU_NETWORK);
        break;
    case 9:
        addDynamicBridgeToTelliumCmd();
        displayMenu(MENU_NETWORK);
        break;
    case 10:
        addDynamicBridgeFromTelliumOnlyCmd();
        displayMenu(MENU_NETWORK);
        break;
    case 11:
        addDynamicBridgeToTelliumOnlyCmd();
        displayMenu(MENU_NETWORK);
        break;
    case 99:
        displayMenu(MENU_MAIN);
        break;
    default:
        sout << "This number doesn't exist in the list of available functions " << endl;
        displayMenu(MENU_NETWORK);
    }
}

void actionsTRANSACTION(int apiSelected)
{

    switch (apiSelected) {
    case 1:
        doTransactionCmd("23456");
        displayMenu(MENU_TRANSACTION);
        break;
    case 2:
        doTransactionExCmd();
        displayMenu(MENU_TRANSACTION);
        break;
    case 3:
        doTransactionCmd("995");
        displayMenu(MENU_TRANSACTION);
        break;        
    case 99:
        displayMenu(MENU_MAIN);
        break;
    default:
        sout << "This number doesn't exist in the list of available functions " << endl;
        displayMenu(MENU_TRANSACTION);
    }
}

void actionsLOOPTEST(int apiSelected)
{

    switch (apiSelected) {
    case 1:
        loopStartStop();
        displayMenu(MENU_LOOP_TEST);
        break;
    case 2:
        loopGetFullSN();
        displayMenu(MENU_LOOP_TEST);
        break;        
    case 3:
        loopDoTransaction();
        displayMenu(MENU_LOOP_TEST);
        break;
    case 99:
        displayMenu(MENU_MAIN);
        break;
    default:
        sout << "This number doesn't exist in the list of available functions " << endl;
        displayMenu(MENU_LOOP_TEST);
    }
}


void actionsPRINTER(int apiSelected)
{
    switch (apiSelected) {
    case 1:
        printTextCmd();
        displayMenu(MENU_PRINTER);
        break;
    case 2:
        printBitmapCmd();
        displayMenu(MENU_PRINTER);
        break;
    case 3:
        storeLogoCmd();
        displayMenu(MENU_PRINTER);
        break;
    case 4:
        printLogoCmd();
        displayMenu(MENU_PRINTER);
        break;
    case 5:
        printStatusCmd();
        displayMenu(MENU_PRINTER);
        break;
    case 6:
        printFontTextCmd();
        displayMenu(MENU_PRINTER);
        break;
    case 99:
        displayMenu(MENU_MAIN);
        break;
    default:
        sout << "This number doesn't exist in the list of available functions " << endl;
        displayMenu(MENU_PRINTER);
    }
}

void actionsBARCODE(int apiSelected)
{

    switch (apiSelected) {
    case 1:
        openBarcodeCmd();
        displayMenu(MENU_BARCODE);
        break;
    case 2:
        closeBarcodeCmd();
        displayMenu(MENU_BARCODE);
        break;
    case 3:
        startScanCmd();
        displayMenu(MENU_BARCODE);
        break;
    case 4:
        stopScanCmd();
        displayMenu(MENU_BARCODE);
        break;
    case 5:
        resetBarcodeCmd();
        displayMenu(MENU_BARCODE);
        break;
    case 6:
        getFirmwareVersionCmd();
        displayMenu(MENU_BARCODE);
        break;
    case 7:
        getSettingsVersionCmd();
        displayMenu(MENU_BARCODE);
        break;
    case 8:
        setReadModeCmd();
        displayMenu(MENU_BARCODE);
        break;
    case 9:
        setLightingModeCmd();
        displayMenu(MENU_BARCODE);
        break;
    case 10:
        setImagerModeCmd();
        displayMenu(MENU_BARCODE);
        break;
    case 11:
        setGoodScanBeepCmd();
        displayMenu(MENU_BARCODE);
        break;
    case 12:
        setBeepCmd();
        displayMenu(MENU_BARCODE);
        break;
    case 13:
        enableDisableTriggerCmd();
        displayMenu(MENU_BARCODE);
        break;
    case 14:
        enableSymbologiesCmd();
        displayMenu(MENU_BARCODE);
        break;
    case 15:
        disableSymbologiesCmd();
        displayMenu(MENU_BARCODE);
        break;
    case 16:
        convertSymbologyToTextCmd();
        displayMenu(MENU_BARCODE);
        break;
    case 99:
        displayMenu(MENU_MAIN);
        break;
    default:
        sout << "This number doesn't exist in the list of available functions " << endl;
        displayMenu(MENU_BARCODE);
        break;
    }
}

void displayMenu(int menu)
{
    g_currentMenu = menu;
    sout << endl;
    sout << "*******************************" << endl;
    sout << "* PCLTestAppForLinux terminal *" << endl;
    sout << "*******************************" << endl;

    switch (menu) {
    case MENU_PARAMETERS:
        display_parameters_menu();
        break;
    case MENU_MAIN:
        sout << endl
             << "Following actions are available: " << endl;
        sout << "	0 - Start Service " << endl;
        sout << "	1 - Stop Service " << endl;
        sout << "	2 - Infos " << endl;
        sout << "	3 - Admin " << endl;
        sout << "	4 - Network " << endl;
        sout << "	5 - Transaction " << endl;
        sout << "	6 - Printer" << endl;
        sout << "	7 - Barcode" << endl;
        sout << "	8 - Loop Test" << endl;
        sout << "	998 - Parameters" << endl;
        sout << "	999 - Refresh " << endl;
        sout << "	1000 - Quit " << endl;
        break;
    case MENU_LOOP_TEST:
        sout << endl
             << "Following actions are available: " << endl;
        sout << "	1 - Start/Stop Service " << endl;
        sout << "	2 - Get Full Serial Number " << endl;
        sout << "	3 - Do Transaction" << endl;
        sout << "	99 - Parent menu" << endl;
        break;
    case MENU_INFO:
        sout << endl
             << "Following actions are available: " << endl;
        sout << "	1 - Get Infos " << endl;
        sout << "	2 - Get Terminal Components " << endl;
        sout << "	3 - Get Full Serial Number " << endl;
        sout << "	4 - Get SPMCI Version " << endl;
        sout << "	5 - Get Battery Level " << endl;
        sout << "	99 - Parent menu" << endl;
        break;
    case MENU_ADMIN:
        sout << endl
             << "Following actions are available: " << endl;
        sout << "	1 - Get Time " << endl;
        sout << "	2 - Set Time " << endl;
        sout << "	3 - Reset " << endl;
        sout << "	4 - Input Simulation " << endl;
        sout << "	5 - Shortcut " << endl;
        sout << "	6 - Lock Backlight " << endl;
        sout << "	7 - Unlock Backlight " << endl;
        sout << "	99 - Parent menu" << endl;
        break;
    case MENU_NETWORK:
        sout << endl
             << "Following actions are available: " << endl;
        sout << "	1 - Send Message (message: Hello spm) " << endl;
        sout << "	2 - Receive Message " << endl;
        sout << "	3 - Flush Message " << endl;
        sout << "	4 - DoUpdate " << endl;
        sout << "	5 - Tms Read Parameters " << endl;
        sout << "	6 - Tms Write Parameters T2 " << endl;
        sout << "	7 - Tms Write Parameters T3 " << endl;
        sout << "	8 - Add Dynamic Bridge From Telium and listen (port: 9834)" << endl;
        sout << "	9 - Add Dynamic Bridge To Telium and connect (port: 9835)" << endl;
        sout << "	10 - Add Dynamic Bridge From Telium Only (port: 5001)" << endl;
        sout << "	11 - Add Dynamic Bridge To Telium Only (port: 5000)" << endl;
        sout << "	99 - Parent menu" << endl;
        break;
    case MENU_TRANSACTION:
        sout << endl
             << "Following actions are available: " << endl;
        sout << "	1 - Do Transaction (amount:234,56, currency:958)" << endl;
        sout << "	2 - Do Transaction Ex (amount:234,56, currency:958)" << endl;
        sout << "	3 - Do Transaction ContactLess (amount:9,95, currency:958)" << endl;
        sout << "	99 - Parent menu" << endl;
        break;
    case MENU_PRINTER:
        sout << endl
             << "Following actions are available: " << endl;
        sout << "	1 - Print Text " << endl;
        sout << "	2 - Print Bitmap " << endl;
        sout << "	3 - Store Logo " << endl;
        sout << "	4 - Print Logo " << endl;
        sout << "	5 - Print Status " << endl;
        sout << "	6 - Print Font " << endl;
        sout << "	99 - Parent menu" << endl;
        break;
    case MENU_BARCODE:
        sout << endl
             << "Following actions are available: " << endl;
        sout << "	1 - Open Barcode" << endl;
        sout << "	2 - Close Barcode" << endl;
        sout << "	3 - Start Scan" << endl;
        sout << "	4 - Stop Scan" << endl;
        sout << "	5 - Reset Barcode" << endl;
        sout << "	6 - Get Firmware Version" << endl;
        sout << "	7 - Get Settings Version" << endl;
        sout << "	8 - Set Reader Mode (to multiscan)" << endl;
        sout << "	9 - Set Lighting Mode (to aperture priority)" << endl;
        sout << "	10 - Set Imager Mode (to 1D 2D)" << endl;
        sout << "	11 - Set Good Scan Beep (to two beeps)" << endl;
        sout << "	12 - Set Beep (frequency: 5000, length: 2500)" << endl;
        sout << "	13 - Enable/Disable Trigger" << endl;
        sout << "	14 - Enable Symbology (enable ICBarCode_EAN13 and ICBarCode_EAN8)" << endl;
        sout << "	15 - Disable Symbology (disable ICBarCode_EAN13 and ICBarCode_EAN8)" << endl;
        sout << "	16 - Convert Symbology To Text" << endl;
        sout << "	99 - Parent menu" << endl;
        break;
    default:
        sout << "This number doesn't exist in the list of available functions " << endl;
        displayMenu(MENU_MAIN);
        g_currentMenu = MENU_MAIN;
        break;
    }
}

string getPPPStatusCmd()
{
    char result;

    if (serverStatus(&result)) {
        if (result != 0) {
            return "Terminal connected";
        } else {
            return "Terminal disconnected";
        }
    } else {
        return "Terminal disconnected";
    }
}

void startServiceCmd()
{
    if (startPclService()) {
        sout << "START SERVICE OK" << endl;
    } else {
        sout << "START SERVICE KO" << endl;
    }
}

void stopServiceCmd()
{
    if (stopPclService()) {
        sout << "STOP SERVICE OK" << endl;
    } else {
        sout << "STOP SERVICE KO" << endl;
    }
}
