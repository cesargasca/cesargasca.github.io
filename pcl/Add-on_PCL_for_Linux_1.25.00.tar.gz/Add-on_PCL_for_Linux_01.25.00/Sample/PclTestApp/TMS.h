#ifndef TMS_H_
#define TMS_H_

void doUpdateCmd();
void tmsReadParametersCmd();
void tmsWriteParametersT2Cmd();
void tmsWriteParametersT3Cmd();

#endif /* TMS_H_ */
