#ifndef MSTREAM_H
#define MSTREAM_H
#include <fstream>
#include <iostream>
#include <ios>
#include <string>

#ifndef MSTREAM_INT
#define EXT extern
#else
#define EXT
#endif

class mstream
{
    public:
    std::ofstream coss;
    mstream(void);
    ~mstream(void);

    mstream& operator<< (std::ostream& (*pfun)(std::ostream&));
    void unsetf(std::_Ios_Fmtflags __mask);
};


template <class T>
 mstream& operator<< (mstream& st, T val)
{
    if(st.coss.is_open())
    {
        st.coss << val;
    }
    std::cout << val;
    return st;
};

EXT mstream sout;

#undef EXT
#endif