#include <iostream>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <vector>
#include "Message.h"
#include "pdaUtil.h"
#include "mstream.h"

using namespace std;


void sendMessageCmd() {
	char *message = "Message to tellium";
	unsigned int bytesSent;
	if(sendMessage(message, sizeof(message), &bytesSent)){
		if(bytesSent != 0){
			sout << "SEND MESSAGE OK" << endl;
		} else {
			sout << "SEND MESSAGE KO" << endl;
		}
	} else {
		sout << "SEND MESSAGE KO" << endl;
	}
}

void receiveMessageCmd(){
    char outBuffer[1024];
    unsigned int bytesReceived;

    if(receiveMessage(outBuffer, sizeof(outBuffer), &bytesReceived)){
    	sout << "RECEIVE MESSAGE OK" << endl;

        if(bytesReceived != 0){
            sout << "Bytes received: " << bytesReceived << endl;
			sout << "Message: " << outBuffer << endl;
        } else {
        	sout << "NO MESSAGE RECEIVED" << endl;
        }
    } else {
    	sout << "RECEIVE MESSAGE KO" << endl;
    }
}

void flushMessageCmd(){
    if(flushMessages()){
    	sout << "FLUSH MESSAGE OK" << endl;
    } else {
    	sout << "FLUSH MESSAGE KO" << endl;
    }
}
