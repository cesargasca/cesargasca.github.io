#ifndef MESSAGE_H_
#define MESSAGE_H_


void sendMessageCmd();
void receiveMessageCmd();
void flushMessageCmd();


#endif /* MESSAGE_H_ */
