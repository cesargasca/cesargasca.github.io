#define MSTREAM_INT
#include "mstream.h"
#undef MSTREAM_INT


mstream::mstream()
{

}

mstream::~mstream()
{

}

mstream& mstream::operator<< (std::ostream& (*pfun)(std::ostream&))
{
    if(coss.is_open()) pfun(coss);
    pfun(std::cout);
    return *this;
}

void mstream::unsetf(std::_Ios_Fmtflags __mask)
{ 
    std::cout.unsetf(__mask);
    if(coss.is_open()) coss.unsetf(__mask);
}

