#include "Network.h"
#include "pdaUtil.h"
#include <arpa/inet.h>
#include <ctime>
#include <errno.h>
#include <iostream>
#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>
#include <vector>
#include "mstream.h"

using namespace std;

typedef sockaddr_in SOCKADDR_IN;
typedef sockaddr SOCKADDR;

void addDynamicBridgeFromTelliumCmd()
{
    int port = 9834;
    SOCKET sock = socket(AF_INET, SOCK_STREAM, 0);
    SOCKADDR_IN sin = { 0 };

    sout << "Port used: " << port << endl;

    sin.sin_port = htons(port);
    sin.sin_family = AF_INET;
    sin.sin_addr.s_addr = htonl(INADDR_LOOPBACK);

    int result = addDynamicBridge(port, BRIDGE_FROM_TELIUM);
    if (result == 0) {
        sout << "ADD DYNAMIC BRIDGE FROM TELLIUM OK" << endl;

        if (bind(sock, (SOCKADDR*)&sin, sizeof(sin)) == SOCKET_ERROR) {
            sout << "bind KO Error:" << strerror(errno) << endl;
            return;
        } else {
            sout << "bind OK" << endl;
        }

        if (listen(sock, 1) == SOCKET_ERROR) {
            sout << "listen KO Error:" << strerror(errno) << endl;
            return;
        } else {
            sout << "listen OK" << endl;
        }

        SOCKADDR_IN csin = { 0 };
        int csock;
        socklen_t sinsize = sizeof(csin);

        sout << "Waiting connection..." << endl;
        csock = accept(sock, (SOCKADDR*)&csin, &sinsize);

        if (csock == INVALID_SOCKET) {
            sout << "accept failed with error " << errno << endl;
            close(sock);
            return;
        }

        int sendRet = 0, retRecv = 0;
        char bufferReceived[2048];
        int bytes_sent = 0, bytes_recvd = 0, pkt_recvd = 0, pkt_sent=0;
        sout << "Waiting receive..." << endl;
        while (1)
        {
            retRecv = recv(csock, (char*)bufferReceived, sizeof(bufferReceived), 0);
            if (retRecv < 0) {
                sout << "recv failed with error " << errno << endl;
                break;
            }

            if (retRecv == 0) {
                break;
            }

            if (retRecv > 0) {
                bytes_recvd += retRecv;
                pkt_recvd++;
                sout << "Sent: " << bytes_sent << " bytes ("<< pkt_sent << ") / Recvd: " << bytes_recvd << " bytes (" << pkt_recvd << ")" << endl;               
                sendRet = send(csock, (char*)bufferReceived, retRecv, 0);
                if (sendRet == SOCKET_ERROR) {
                    sout << "send failed with error " << errno << endl;
                    break;
                }
                bytes_sent += sendRet;
                pkt_sent++;
                sout << "Sent: " << bytes_sent << " bytes ("<< pkt_sent << ") / Recvd: " << bytes_recvd << " bytes (" << pkt_recvd << ")" << endl;
            }
        }
        close(csock);
        close(sock);
    } else {
        sout << "ADD DYNAMIC BRIDGE FROM TELLIUM KO result =" << result << endl;
    }
}

void addDynamicBridgeToTelliumCmd()
{

    int port = 9835;
    SOCKET sock = socket(AF_INET, SOCK_STREAM, 0);
    SOCKADDR_IN sin = { 0 };

    sin.sin_port = htons(port);
    sin.sin_family = AF_INET;
    sin.sin_addr.s_addr = htonl(INADDR_LOOPBACK);

    sout << "Trying to connect to terminal port: " << port << endl;

    int result = addDynamicBridge(port, BRIDGE_TOWARDS_TELIUM);
    if (result == 0) {
        sout << "ADD DYNAMIC BRIDGE TO TELLIUM OK" << endl;

        usleep(50000);

        if (connect(sock, (SOCKADDR*)&sin, sizeof(sin)) == SOCKET_ERROR) {
            sout << "Connect Error:" << strerror(errno) << endl;
            return;
        } else {
			int packetSize = 128, packetNumber = 12;
			int bytes_sent = 0, bytes_recvd = 0;
			char bufferToSend[150], bufferReceived[150];
			
            sout << "Connected" << endl;

            for (int i = 0; i <= packetSize; i++) {
                bufferToSend[i] = i;
            }

            clock_t begin = clock();
            while (packetNumber--) {
				int rx = 0;
				result = send(sock, bufferToSend, packetSize, 0);
                if (result < 0) {
                    sout << "send failed with error " << errno << endl;
                    break;
				}
				
                bytes_sent += result;
                sout << "Sent: " << bytes_sent << " / Recvd: " <<  bytes_recvd << endl;

                do {
                    if ((result = recv(sock, (char*)&bufferReceived[rx], sizeof(bufferReceived) - rx, 0)) < 0) {
                        sout << "recv failed with error " << errno << endl;
                    } else if (result == 0) {
                        sout << "socket closed by peer" << endl;
                    } else {
                        rx += result;
                        bytes_recvd += result;
                        sout << "Sent: " << bytes_sent <<" / Recvd: l" << bytes_recvd << endl;
                    }

                } while ((result > 0) && (rx < packetSize));
                if (result <= 0) {
                    break;
                }
            }
            if (result == 0) {
                clock_t end = clock();
                double tickResult = 1000.0 * double(end - begin) / CLOCKS_PER_SEC;
                if (tickResult != 0) {
					sout << "Sent: " << bytes_sent << "/ Recvd" << bytes_recvd << "time = " << tickResult << " ms Bit rate = " 
					<< ((bytes_sent + bytes_recvd) * 8000) / tickResult << "bits/s" << endl;
                } else {
                    sout << "Sent: " << bytes_sent << "/ Recvd" << bytes_recvd << "time = " << tickResult << " ms " << endl;
                }
            }
        }

    } else {
        sout << "ADD DYNAMIC BRIDGE TO TELLIUM KO result =" << result << endl;
    }
}

void addDynamicBridgeFromTelliumOnlyCmd()
{
    int port = 5001;
    sout << "Port used: " << port << endl;
    int result = addDynamicBridge(port, BRIDGE_FROM_TELIUM);
    if (result == 0) {
        sout << "ADD DYNAMIC BRIDGE FROM TELLIUM OK" << endl;
    } else {
        sout << "ADD DYNAMIC BRIDGE FROM TELLIUM KO result =" << result << endl;
    }
}

void addDynamicBridgeToTelliumOnlyCmd()
{
    int port = 5000;
    sout << "Port used: " << port << endl;
    int result = addDynamicBridge(port, BRIDGE_TOWARDS_TELIUM);
    if (result == 0) {
        sout << "ADD DYNAMIC BRIDGE TO TELLIUM OK" << endl;
    } else {
        sout << "ADD DYNAMIC BRIDGE TO TELLIUM KO result =" << result << endl;
    }
}