#ifndef TRANSACTION_H_
#define TRANSACTION_H_


void doTransactionCmd(char* pAmont);
void doTransactionExCmd();


#endif /* TRANSACTION_H_ */
