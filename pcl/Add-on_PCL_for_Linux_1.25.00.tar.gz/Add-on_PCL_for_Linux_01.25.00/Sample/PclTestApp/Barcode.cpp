#include <iostream>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <vector>
#include "Barcode.h"
#include "pdaUtil.h"
#include "mstream.h"

using namespace std;

int enableDisableTriggerBool = 0;

void openBarcodeCmd(){
    char result;
    openBarcode(&result);

    if(result == 0){
        sout << "OPEN BARCODE OK" << endl;
    } else {
    	sout << "OPEN BARCODE KO" << endl;
    }
}

void closeBarcodeCmd(){
    char result;
    closeBarcode(&result);

    if(result == 0){
    	sout << "CLOSE BARCODE OK" << endl;
    } else {
    	sout << "CLOSE BARCODE KO" << endl;
    }
}

void startScanCmd(){
    char result;
    bcrStartScan(&result);

    if(result == 0){
    	sout << "BARCODE START SCAN OK" << endl;
    } else {
    	sout << "BARCODE START SCAN KO" << endl;
    }
}

void stopScanCmd(){
    char result;
    bcrStopScan(&result);

    if(result == 0){
    	sout << "BARCODE STOP SCAN OK" << endl;
    } else {
    	sout << "BARCODE STOP SCAN KO" << endl;
    }
}

void resetBarcodeCmd(){
    char result;
    bcrSoftReset(&result);

    if(result == 0){
    	sout << "RESET BARCODE OK" << endl;
    } else {
    	sout << "RESET BARCODE KO" << endl;
    }
}

void getFirmwareVersionCmd(){
    char version[256];
    BOOL result = bcrGetFirmwareVersion(version, 256);

    if(result == 1){
        sout << version << endl;
    } else {
        sout << "GET FIRMWARE KO" << endl;
    }
}

void getSettingsVersionCmd(){
    unsigned char version[2] = {0};
    char versionFinal[12];

	if(bcrGetSettingsVersion((char*)version,sizeof(version))){
		sprintf(versionFinal, "%02X%02X\0", version[0], version[1]);
		sout << versionFinal << endl;
	} else {
		sout << "GET SETTINGS VERSION KO" << endl;
	}
}

void setReadModeCmd(){
	//Multiple scan
    int modeType = 1;
    char result;

    bcrSetReaderMode(modeType, &result);

    if(result == 0){
        sout << "READER MODE OK" << endl;
    } else {
        sout << "READER MODE KO" << endl;
    }
}

void setLightingModeCmd(){
	//APERTURE PRIORITY
    int mode = 1;
    char result;
    bcrSetLightingMode(mode, &result);

    if(result == 0){
        sout << "LIGHTING MODE OK" << endl;
    } else {
        sout << "LIGHTING MODE KO" << endl;
    }
}

void setImagerModeCmd(){
	//IMAGER MODE 1D 2D
    int imagerMode = 1;
    char result;

    bcrSetImagerMode(imagerMode, &result);

    if(result == 0){
        sout << "IMAGER MODE OK" << endl;
    } else {
        sout << "IMAGER MODE KO" << endl;
    }
}

void setGoodScanBeepCmd(){
	//TWO BEEPS
    int modeBeep = 2;
    char result;
    bcrSetGoodScanBeep(modeBeep, &result);

    if(result == 0){
        sout << "GOOD SCAN BEEP OK" << endl;
    } else {
        sout << "GOOD SCAN BEEP KO" << endl;
    }
}

void setBeepCmd(){
    int freq = 5000;
    int length = 2500;
    char result;
    bcrSetBeep(freq, length, &result);

    if(result == 0) {
        sout << "SET BEEP OK" << endl;
    } else {
        sout << "SET BEEP KO" << endl;
    }
}

void enableDisableTriggerCmd(){
    int triggerMode = enableDisableTriggerBool;
    char result;

    bcrEnableTrigger(triggerMode, &result);

    if (result == 0){
    	sout << "ENABLE/DISABLE TRIGGER OK" << endl;
    } else {
        sout << "ENABLE/DISABLE TRIGGER KO" << endl;
    }

    if(enableDisableTriggerBool == 0){
    	enableDisableTriggerBool = 1;
    } else {
    	enableDisableTriggerBool = 0;
    }
}

void enableSymbologiesCmd(){
	char result;
	int *symbos = new int[2];
	symbos[0] = ICBarCode_EAN13;
	symbos[1] = ICBarCode_EAN8;

	bcrEnableSymbologies(symbos, 2, &result);

    if(result == 0){
    	sout << "ENABLE SYMBOLOGY OK" << endl;
    } else {
    	sout << "ENABLE SYMBOLOGY KO" << endl;
    }
}

void disableSymbologiesCmd(){

	char result;
	int *symbos = new int[2];
	symbos[0] = ICBarCode_EAN13;
	symbos[1] = ICBarCode_EAN8;

	bcrDisableSymbologies(symbos, 2, &result);

    if(result == 0){
    	sout << "DISABLE SYMBOLOGY OK" << endl;
    } else {
    	sout << "DISABLE SYMBOLOGY KO" << endl;
    }
}

void convertSymbologyToTextCmd(){
	int symbo = ICBarCode_EAN13;
	char * result = bcrSymbologyToText(symbo);
	sout << "Symbology: " << result << endl;
}

