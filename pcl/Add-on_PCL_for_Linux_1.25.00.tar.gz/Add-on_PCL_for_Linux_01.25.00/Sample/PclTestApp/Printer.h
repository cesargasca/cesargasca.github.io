#ifndef PRINTER_H_
#define PRINTER_H_

void printTextCmd();
void printBitmapCmd();

void storeLogoCmd();
void printLogoCmd();
void printStatusCmd();
void setPrintFontCmd();
void printFontTextCmd();


#endif /* PRINTER_H_ */
