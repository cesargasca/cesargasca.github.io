package com.ingenico.ipclbridge;

public enum ResultCode
{
	Success,
	NotEnoughMemmory, UnableReadComPort, ReadNothing, UnableToReadPropertiesFile, UnableToWritePropertiesFile, PclUtilIpRecvError, NotImplemented,
	NoMoreDynamicBridgeAvailable, BridgeAlreadyExists, IssueDuringThreadCreation, BridgeInitializationFailed, PCLserviceIsNotStarted,
	NoPortAvailable, InvalidPort, NoRasEntry, NoIpCompanion, MemoryError, ErrorActivatePrivilegies, UserCancelled, 
	ErrorWrongDevice, Unknown;
						
	static ResultCode fromInteger(int code)
	{
		switch(code)
		{
			case 0: 	return Success;
			case 2:		return NotEnoughMemmory;
			case 3:		return UnableReadComPort;
			case 4: 	return ReadNothing;
			case 5:		return UnableToReadPropertiesFile;
			case 6:		return UnableToWritePropertiesFile;
			case 7:		return PclUtilIpRecvError;
			case 8:		return NotImplemented;
			case -1: 	return NoMoreDynamicBridgeAvailable;
			case -2: 	return BridgeAlreadyExists;
			case -3: 	return IssueDuringThreadCreation;
			case -4: 	return BridgeInitializationFailed;
			case -5: 	return PCLserviceIsNotStarted;
			case 61000: return NoPortAvailable;
			case 61001: return InvalidPort;
			case 61002: return NoRasEntry;
			case 61003: return NoIpCompanion;
			case 61100: return MemoryError;
			case 61101: return ErrorActivatePrivilegies;
			case 61102: return UserCancelled;
			default: 	return Unknown;
		}
	}
	static int toInteger(ResultCode code)
	{
		switch(code)
		{
			case Success: 						return 0;
			case NotEnoughMemmory:				return 2;
			case UnableReadComPort:				return 3;
			case ReadNothing: 					return  4;
			case UnableToReadPropertiesFile:	return 5;
			case UnableToWritePropertiesFile:	return 6;
			case PclUtilIpRecvError:			return 7;
			case NotImplemented:				return 8;
			case NoMoreDynamicBridgeAvailable:	return -1;
			case BridgeAlreadyExists: 			return -2;
			case IssueDuringThreadCreation: 	return -3;
			case BridgeInitializationFailed: 	return -4;
			case PCLserviceIsNotStarted: 		return -5;
			case NoPortAvailable: 				return 61000;
			case InvalidPort: 					return 61001;
			case NoRasEntry: 					return 61002;
			case NoIpCompanion: 				return 61003;
			case MemoryError: 					return 61100;
			case ErrorActivatePrivilegies: 		return 61101;
			case UserCancelled: 				return 61102;
			case Unknown: 						return 0x80000000;
			default: 							return 0x80000000;
		}
	}
};
