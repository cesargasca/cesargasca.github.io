package com.ingenico.ipclbridge;

public enum StatusCode
{
	CompanionNotConnected, CompanionConnected, Unknown;
	
	static StatusCode fromInteger(int code)
	{
		switch(code)
		{
			case 0: 	return CompanionNotConnected;
			case 1: 	return CompanionConnected;
			default: 	return Unknown;
		}
	}
	static int toInteger(StatusCode code)
	{
		switch(code)
		{
			case CompanionNotConnected: return 0;
			case CompanionConnected:	return 1;
			case Unknown:				return 0x80000000;
			default: 					return 0x80000000;
		}
	}
};