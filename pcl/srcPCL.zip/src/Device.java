package com.ingenico.ipclbridge;

import java.util.ArrayList;
import java.util.List;

public class Device
{
	static
	{
		//System.getProperties().list(System.out);
		if( System.getProperty("os.name").startsWith("Windows") )
		{
			System.loadLibrary("dllsign");
			System.loadLibrary("PclUtilities");
			System.loadLibrary("PCLService");
		}
        System.loadLibrary("iPclBridge");
        System.loadLibrary("iPclBridgeJni");
    }
	
    public enum Type
	{
		USB, COM, BT, IP, Unknown;
        private static String toString(Type type)
        {
            switch (type)
            {
                case USB: return "USB";
                case COM: return "COM";
                case BT:  return "BT";
                case IP:  return "IP";
            }
            return "";
        }
		private static Type getType(String type)
		{
            switch (type)
            {
                case "USB": return Type.USB;
                case "COM": return Type.COM;
                case "BT":  return Type.BT;
                case "IP":  return Type.IP;
            }
            return Type.Unknown;
        }
	};

    public Type type = Type.Unknown;
    public String address;
    public String name;
    public Boolean active = false;
    public Boolean ssl = false; 

    public static List<Device> getPaired()
    {
		List<Device> devices = new ArrayList<>();
        String devId = getPclDeviceNative();
        while( !devId.isEmpty() )
        {
            devices.add(new Device(devId));
            devId = getPclNextDeviceNative();
        }
        return devices;
    }

	public static Device getActive()
    {
		String devId = getActivatedPclDeviceNative();
        return new Device(devId);
    }

	/**
	 * Create Device with Type and low level address. The new device has not active.
	 * @param type type of the device
	 * @param address low level address of the device
	 * @param name the name of the device
	 */
	public static Device createDevice(Type type, String address, String name) {
		String devId = String.format("%1$s:%2$s:%3$s:%4$s:%5$s", Type.toString(type), address, name, boolToString(false), boolToString(false));
		return new Device(devId);
	} 

    public ResultCode activate()
    {
		String devId = String.format("%1$s:%2$s:%3$s:%4$s:%5$s", Type.toString(this.type), this.address, this.name, boolToString(this.active), boolToString(this.ssl));
        return ResultCode.fromInteger(activatePclDeviceNative(devId));
    }
	

    private Device(String devId)
    {
        //  TYPE:ADDRESS:NAME:ACTIVE:SSL
        String[] devids = devId.split(":");
        if (devids.length > 0)
            this.type = Type.getType(devids[0]);
        if (devids.length > 1)
            this.address = devids[1];
        if (devids.length > 2)
            this.name = devids[2];
        if (devids.length > 3)
            this.active = stringToBool(devids[3]);
        if (devids.length > 4)
            this.ssl = stringToBool(devids[4]);
    }

    private static Boolean stringToBool(String active)
    {
        return active.equals("YES");
    }
    private static String boolToString(Boolean active)
    {
        return active == true ? "YES" : "NO";
    }

	private static native String getPclDeviceNative();
    private static native String getPclNextDeviceNative();
    private native int activatePclDeviceNative(String deviceId);
    private static native String getActivatedPclDeviceNative();
	
};
	