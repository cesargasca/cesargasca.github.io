package com.ingenico.ipclbridge;

public class PPPchannel
{
	static
	{
		if( System.getProperty("os.name").startsWith("Windows") )
		{
			System.loadLibrary("dllsign");
			System.loadLibrary("PclUtilities");
			System.loadLibrary("PCLService");
		}
        System.loadLibrary("iPclBridge");
        System.loadLibrary("iPclBridgeJni");
    }
	
    public enum Direction
	{
		ToDevice, FromDevice; 
		static Direction fromInteger(int direction)
		{
			switch(direction)
			{
				case 0: 	return ToDevice;
				case 1: 	return FromDevice;
				default: 	return ToDevice;
			}
		}
		static int toInteger(Direction direction)
		{
			switch(direction)
			{
				case ToDevice: 	return 0;
				case FromDevice:return 1;
				default: 		return 0;
			}
		}	
	}

    public static ResultCode start()
    {
        return ResultCode.fromInteger(startPclNative());
    }

    public static ResultCode add(int port, Direction direction)
    {
        return ResultCode.fromInteger(addPclPPPchannelNative(port, Direction.toInteger(direction)));
    }

    public static ResultCode stop()
    {
        return ResultCode.fromInteger(stopPclNative());
    }

    public static StatusCode status()
    {
        return StatusCode.fromInteger(serverStatusNative());
    }
	
	// location of the PCL trace file: <user>\AppData\Roaming\Ingenico\PCLService.log
    public static void EnablePclLog(Boolean enable)
    {
        enablePclLogNative(enable ? 1 : 0);
    }
	
	private static void sleep(int msec)
	{
		try { Thread.sleep(msec);  }
		catch (Exception e) {}
	}

    private static native int startPclNative();
    private static native int addPclPPPchannelNative(int port, int direction);
    private static native int stopPclNative();
    private static native int serverStatusNative();
	private static native void enablePclLogNative(int enable);
}
