//
//  PclMacOS.h
//  PclMacOS
//
//  Created by Pierre MONOD-BROCA on 08/12/2016.
//  Copyright © 2016 Ingenico. All rights reserved.
//

#import <Cocoa/Cocoa.h>

////! Project version number for PclMacOS.
//FOUNDATION_EXPORT double PclMacOSVersionNumber;
//
////! Project version string for PclMacOS.
//FOUNDATION_EXPORT const unsigned char PclMacOSVersionString[];

// Importing all public headers
#import "PDAUtil.h"
#import "TransactionIn.h"
#import "TransactionOut.h"
#import "Transaction.h"
