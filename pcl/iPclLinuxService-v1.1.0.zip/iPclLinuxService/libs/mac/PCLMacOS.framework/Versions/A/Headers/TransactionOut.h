//
//  TransactionOut.h
//  PclMacOS
//
//  Created by Pierre MONOD-BROCA on 16/12/2016.
//  Copyright © 2016 Ingenico. All rights reserved.
//
/*!
    @file       TransactionOut.h
    @brief      Header file of objective-c class TransactionOut
*/

#import <Foundation/Foundation.h>

/** Represents transaction result */
@interface TransactionOut : NSObject

/** Get amount used for transaction.
 @return amount in the smaller currency used for the transaction, limited to 8 digits. */
- (char *)amount;
/** Get error code for transaction.
 @return error code.
 @see ErrorCode */
- (char *)c3Error;
/** Get currency code used for transaction.
 @return currency code for the transaction (See <a href="http://www.iso.org/iso/home/standards/currency_codes.htm">ISO 4217</a>) */
- (char *)currencyCode;
/** Get terminal number.
 @return Terminal number, limited to 2 digits. */
- (char *)terminalNumber;
/** Get user data.
 @return User data, only 10 bytes should be meaningful. */
- (char *)userData1;
/** Get private data.
 @return Private data*/
- (char *)privateData;

@end
