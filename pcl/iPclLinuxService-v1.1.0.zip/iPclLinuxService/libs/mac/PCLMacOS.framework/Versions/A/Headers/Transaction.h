//
//  Transaction.h
//  PclMacOS
//
//  Created by Pierre MONOD-BROCA on 16/12/2016.
//  Copyright © 2016 Ingenico. All rights reserved.
//
/*!
    @file       Transaction.h
    @brief      Header file of APIs to perform transactions
*/

#import <Foundation/Foundation.h>

#ifdef __cplusplus
extern "C"{
#endif

@class TransactionIn;
@class TransactionOut;


/** Launches a transaction request, passing the input parameters to the companion payment application.
 The output parameters are filled with the response from the companion payment application.
 @param transactionReq Transaction request parameters
 @param transactionResp Transaction response parameters. Call getC3Error to check transaction result.
 @return TRUE in case of success, FALSE in case of failure */
BOOL doTransaction(TransactionIn *transactionReq, TransactionOut* transactionResp);

/** Launches a transaction request with extended parameters, passing the input parameters to the companion payment application.
 The output parameters are filled with the response from the companion payment application.
 @param transactionReq Transaction request parameters
 @param transactionResp Transaction response parameters. Call getC3Error to check transaction result.
 @param nApplicationNumber Specifies explicitely the Telium application to run on the companion (this application must implements PDA_START_TRANSACTION service)
 @param inBuffer Pointer to the input extended data
 @param inBufferSize Size of the input extended data
 @param outBuffer Pointer to the output extended data
 @param outBufferSize On input, size of the output buffer. On output, size of the extended data received from the companion.
 @return TRUE in case of success, FALSE in case of failure */
BOOL doTransactionEx(TransactionIn *transactionReq, TransactionOut *transactionResp, unsigned short nApplicationNumber, unsigned char *inBuffer, unsigned long inBufferSize, unsigned char *outBuffer, unsigned long *outBufferSize);

#ifdef __cplusplus
}
#endif
