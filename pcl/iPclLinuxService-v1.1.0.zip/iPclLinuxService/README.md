# iPclLinuxService V1.1.0

## Package content

1. libs
    * windows
    * linux
    * mac
2. res
    * config.json

3. iPclLinuxService-1.1.0-jar-with-dependencies.jar
4. README.MD (this file)

## Basic config.json

```json
	{
	"address": "ttyACM0",
	"direction": 0,
	"port": 50000,
	"log" : {
          "level": "INFO",
          "maxFileSize" : "100MB",
          "maxLogFiles" : "10"
    }
}

```

*	address ```String```:
     - Device's address for example "ttyACM0"
>Note: For Linux addresses it must be set without /dev/

*	direction ```int```:
     -	0 : From PC to device
     -  1 : From device to PC 

*	port ```int```: 
      - Port where the PCL is listening

*	log:
      - level ```String```:
        -	DEBUG (Default)
        -	INFO
        -	WARN
        -	ERROR
        -	FATAL
        -	OFF
      - maxFileSize ```String```:
        - Following the next Regex ``[1-9]{1}[0-9]*(KB|MB|GB)``
      - maxLogFiles ```String```:
        - Maximum log files archived 
      

## Usage

### Linux
1. Export LD_LIBRARY_PATH
   ```
   export LD_LIBRARY_PATH="PATH_TO_LIBS_LINUX"
   ```
2. UDEV rule (optional) <br/>
   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Linux usually rename plugged devices causing connectivity issues with the iPclLinuxService this can be solved with UDEV rule which creates more or less a symbolic link to our device based on PID and VID. This way you can configure the service to always connect to a device like “*my_device*” and Linux handles the rest. To create a UDEV rule follow the next steps:

    1.  Run the following command, inserting a `<devpath>` such as **/dev/ttyACM0:**
    ```
    udevadm info -a -p $(udevadm info -q path -n `<devpath>`)
    ```

    3. look for **ATTR{idVendor}** and **ATTR{idProduct}**
    4. Create file in **/lib/udev/rules.d/10-local-1.rules** and add the following line (this is an example of our device lane/7000):

    ```
    ACTION==”add”, ATTR{idProduct}==”0056”, ATTR{idVendor}==”0b00”, SYMLINK=”my_lane_7000”
    ```
    5.  Run ```udevadm trigger```

3.  Run service
    ```
    java -Djava.library.path=libs/linux -jar iPclLinuxService-1.0-SNAPSHOT-jar-with-dependencies.jar <option>
    ```
    **Available options**
    *	start: Start service
    *	scan: Scan available devices for activation
    > Note: In order to activate devices superuser permissions might be required

## LOGS
* App logs can be found under /tmp/PCLService.log 
* PCLService.log will be archived when it reaches size specified in config/log/maxFileSize as PCLService_N.log.gz where N is the maximum log files archived specified in config/log/maxLogFiles
* PCLUtilities.txt and PCLLog.txt also available under /tmp/