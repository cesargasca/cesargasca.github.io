package org.ingenico.exception;

public class InvalidConfigParameter extends Exception{
    public InvalidConfigParameter(String parameter,String value){
        super(String.format("INVALID %s : %s",parameter,value));
    }
}
