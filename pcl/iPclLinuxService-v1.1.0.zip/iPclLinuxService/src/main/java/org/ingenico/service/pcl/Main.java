package org.ingenico.service.pcl;

import static org.ingenico.service.pcl.Utilities.CommandLineInput;

public class Main {
    public static void main(String[] args) {
        Thread trd = new Thread(() -> {
           while (true){
               CommandLineInput();
           }
        });
        trd.start();
    }
}
