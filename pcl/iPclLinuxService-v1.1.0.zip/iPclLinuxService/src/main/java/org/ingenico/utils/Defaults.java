package org.ingenico.utils;

public class Defaults {
    public static int _PORT = 50000;
    public static int _DIRECTION = 0;

    public static int _MAX_TRIES= 10;

    public static String _version = "1.1.0";

    public static String _CONFIG_FILE = "./res/config.json";

    public static String _MAX_FILE_SIZE_REGEX = "[1-9]{1}[0-9]*(KB|MB|GB)";

}
