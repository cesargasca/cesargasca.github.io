package org.ingenico.service;

import com.ingenico.ipclbridge.Device;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.ingenico.Main;
import org.ingenico.entity.Config;
import org.ingenico.entity.LogConfig;
import org.ingenico.service.pcl.Get_Device;
import org.ingenico.service.pcl.PCL_Implementation;

import java.util.List;
import java.util.regex.Pattern;

import static org.ingenico.utils.Defaults.*;

public class PclServiceImpl implements PclService {
    private static final PCL_Implementation mPclImp = new PCL_Implementation();
    private static final Logger logger = LogManager.getLogger(PclServiceImpl.class);

    private static int tries = 0;
    private static int triesFirst = 0;

    private static boolean _pcl_stop_message_shown = false;

    @Override
    public void start() {

        if (Main.config == null) {
            logger.debug("SETTING DEFAULT CONFIGURATION");
            Main.config = new Config(_PORT, _DIRECTION, new LogConfig());
        }

        if(!mPclImp.PclActive()){
            if(!_pcl_stop_message_shown){
                logger.info("STOPPING PCL PLEASE DO NOT PLUG THE DEVICE UNTIL PROCESS FINISHES...");
                _pcl_stop_message_shown = true;
                if(mPclImp.StopPCL())
                    logger.info("PCL STOPPED");
                else
                    logger.info("PCL ALREADY STOPPED OR NEVER STARTED");
            }
            if(anyDeviceConnected()){
                if(tries <= _MAX_TRIES){
                    logger.info("TRY # {} FOR CONNECTING TO [{}]",tries,Main.config.getAddress());
                    if (mPclImp.StartPCL(Main.config.getAddress(), Main.config.getPort(), Main.config.getDirection())) {
                        tries = 0;
                        triesFirst = 0;
                        _pcl_stop_message_shown = false;
                        logger.info("PCL STARTED ON [{}]",Main.config.getAddress(),Main.config.getPort());
                    } else {
                        tries++;
                    }
                }else{
                    if(triesFirst <= _MAX_TRIES){
                        Device firstDevice = scan();
                        _pcl_stop_message_shown = false;
                        logger.info("TRY # {} FOR CONNECTING TO [{}]",triesFirst,firstDevice.address);
                        if (mPclImp.StartPCL(firstDevice.address, Main.config.getPort(), Main.config.getDirection())) {
                            tries = 0;
                            triesFirst = 0;
                            logger.info("PCL STARTED ON [{}] PORT = [{}]",firstDevice.address,Main.config.getPort());
                        } else {
                            triesFirst++;
                        }
                    }
                }
            }
        }else{
            //logger.info(mPclImp.PclActive());
        }

        if ((tries + triesFirst) == (_MAX_TRIES*2)) {
            logger.debug("MAX TRIES REACHED STARTING AGAIN");
            tries = 0;
            triesFirst = 0;
        }

    }

    @Override
    public void stop() {
    }

    @Override
    public void status() {

    }

    @Override
    public Device scan() {
        List<Device> deviceList = Device.getPaired();
        if (deviceList.isEmpty()) {
            logger.info("NO DEVICES FOUND");
        } else {
            logger.info("DEVICES FOUND");
            for (Device device : deviceList) {
                logger.debug("Type: {}, Address: {}, Name: {}, Active: {}, ssl: {}\n",
                        device.type,
                        device.address,
                        device.name,
                        device.active,
                        device.ssl
                );
            }
        }
        return deviceList.size() > 0 ? deviceList.get(0) : null;
    }

    @Override
    public boolean anyDeviceConnected() {
        return scan() != null;
    }

}
