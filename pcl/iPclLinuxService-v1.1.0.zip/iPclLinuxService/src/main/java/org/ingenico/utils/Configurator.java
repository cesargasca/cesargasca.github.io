package org.ingenico.utils;

import com.google.gson.Gson;
import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.core.Appender;
import org.apache.logging.log4j.core.LoggerContext;
import org.apache.logging.log4j.core.appender.RollingFileAppender;
import org.apache.logging.log4j.core.appender.rolling.DefaultRolloverStrategy;
import org.apache.logging.log4j.core.appender.rolling.SizeBasedTriggeringPolicy;
import org.apache.logging.log4j.core.config.Configuration;
import org.apache.logging.log4j.core.config.LoggerConfig;
import org.ingenico.entity.Config;
import org.ingenico.exception.InvalidConfigParameter;
import org.ingenico.utils.Defaults.*;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;

import static org.ingenico.utils.Defaults._MAX_FILE_SIZE_REGEX;

public class Configurator {
    private static final Logger logger =  LogManager.getLogger(Configurator.class);
    public static void setLogLevel(String level) throws InvalidConfigParameter {
        if(level != null && !level.isEmpty()) {
            LoggerContext ctx = (LoggerContext) LogManager.getContext(false);
            Configuration config = ctx.getConfiguration();
            LoggerConfig loggerConfig = config.getLoggerConfig(LogManager.ROOT_LOGGER_NAME);
            switch (level.toUpperCase()) {
                case "ALL":
                    loggerConfig.setLevel(Level.ALL);
                    break;
                case "TRACE":
                    loggerConfig.setLevel(Level.TRACE);
                    break;
                case "DEBUG":
                    loggerConfig.setLevel(Level.DEBUG);
                    break;
                case "INFO":
                    loggerConfig.setLevel(Level.INFO);
                    break;
                case "WARN":
                    loggerConfig.setLevel(Level.WARN);
                    break;
                case "ERROR":
                    loggerConfig.setLevel(Level.ERROR);
                    break;
                case "FATAL":
                    loggerConfig.setLevel(Level.FATAL);
                    break;
                default:
                    loggerConfig.setLevel(Level.DEBUG);
            }

            ctx.updateLoggers();  // This causes all Loggers to refetch information from their LoggerConfig.
        }else{
            throw new InvalidConfigParameter("log.level",level);
        }
    }

    public static void setMaxLogFiles(String maxLogFiles) throws InvalidConfigParameter {
        if(maxLogFiles != null && !maxLogFiles.isEmpty()){
            LoggerContext ctx = (LoggerContext) LogManager.getContext(false);
            Configuration config = ctx.getConfiguration();
            Appender appender = config.getAppender("fileLogger");
            DefaultRolloverStrategy newStrategy = DefaultRolloverStrategy.newBuilder().withMax(maxLogFiles).build();
            if (appender instanceof RollingFileAppender) {
                ((RollingFileAppender) appender).getManager().setRolloverStrategy(newStrategy);
            }
        }else{
            throw new InvalidConfigParameter("log.maxLogFiles",maxLogFiles);
        }

    }

    public static void setMaxFileSize(String maxFileSize) throws InvalidConfigParameter {
        if(maxFileSize!=null && !maxFileSize.isEmpty() && maxFileSize.toUpperCase().matches(_MAX_FILE_SIZE_REGEX)){
            LoggerContext ctx = (LoggerContext) LogManager.getContext(false);
            Configuration config = ctx.getConfiguration();
            Appender appender = config.getAppender("fileLogger");
            if (appender instanceof RollingFileAppender) {
                ((RollingFileAppender) appender).getManager().setTriggeringPolicy(SizeBasedTriggeringPolicy.createPolicy(maxFileSize));
            }
        }else{
            throw new InvalidConfigParameter("log.maxFileSize",maxFileSize);
        }
    }
    public static Config readConfigFile(){
        BufferedReader br = null;
        Config config = null;
        try {
            br = new BufferedReader(new FileReader(Defaults._CONFIG_FILE));
            config = new Gson().fromJson(br, Config.class);
        } catch (FileNotFoundException e) {
            logger.error("CONFIGURATION FILE NOT FOUND");
        }
        return config;
    }
}
