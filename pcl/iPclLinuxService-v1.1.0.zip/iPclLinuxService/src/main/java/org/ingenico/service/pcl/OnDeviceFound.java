package org.ingenico.service.pcl;

public interface OnDeviceFound {
    void onDeviceFound(String device);
}
