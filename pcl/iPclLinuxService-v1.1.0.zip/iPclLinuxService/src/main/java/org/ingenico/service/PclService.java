package org.ingenico.service;

import com.ingenico.ipclbridge.Device;
import org.ingenico.entity.Config;

public interface PclService {
    public void start();
    public void stop();
    public void status();
    public Device scan();

    public boolean anyDeviceConnected();
}
