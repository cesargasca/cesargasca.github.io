package org.ingenico;

import com.google.gson.Gson;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.ingenico.entity.Config;
import org.ingenico.service.PclService;
import org.ingenico.service.PclServiceImpl;
import org.ingenico.utils.Configurator;
import org.ingenico.utils.Defaults;

import java.io.*;
import java.nio.channels.FileLock;

import static org.ingenico.service.pcl.Utilities.*;
import static org.ingenico.utils.Configurator.readConfigFile;
import static org.ingenico.utils.Configurator.setLogLevel;
import static org.ingenico.utils.Defaults._version;

public class Main {
    private static final Logger logger =  LogManager.getLogger(Main.class);
    public static Config config = readConfigFile();

    public static boolean pcl_active = true;

    public static void main(String[] args) throws IOException {
        PclService service = new PclServiceImpl();
        System.out.println(System.getProperty("java.io.tmpdir"));
        if(args[0].equals("start")){
            try{
                logger.info("STARTING PCL SERVICE VERSION {}", _version);
                if(Main.config == null){
                    logger.error("CONFIG FILE [{}] NOT FOUND", Defaults._CONFIG_FILE);
                }else{
                    Configurator.setLogLevel(config.getLog().getLevel());
                    Configurator.setMaxFileSize(config.getLog().getMaxFileSize());
                    Configurator.setMaxLogFiles(config.getLog().getMaxLogFiles());
                    Thread trd = new Thread(() -> {
                        while(true){
                            service.start();
                        }
                    });
                    trd.start();
                }
            }catch (Exception e){
                logger.error("Exception: ",e);
            }
        }else if(args[0].equals("scan")){
            service.scan();
        }
    }


}