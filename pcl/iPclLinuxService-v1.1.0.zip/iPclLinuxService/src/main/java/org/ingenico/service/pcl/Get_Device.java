package org.ingenico.service.pcl;

import com.ingenico.ipclbridge.PPPchannel;
import com.ingenico.ipclbridge.StatusCode;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;


import static java.lang.Thread.sleep;
import static org.ingenico.service.pcl.Utilities.LogLine;

public class Get_Device {

    private static OnDeviceFound mListner;
    public static void registerOnDeviceFoundListner(OnDeviceFound mListner) {
        Get_Device.mListner = mListner;
    }

    private static final Pattern PORT_NAMES_LINUX = Pattern.compile("(ttyACM)");
    private static final String  PORT_PATH_LINUX = "/dev/";
    private static Thread _findAndNotifyThread = null;

    public static void findDeviceAndNotify(String originalPort) {
        LogLine("Looking for a device...");

        if (_findAndNotifyThread != null && _findAndNotifyThread.isAlive()) {
            LogLine("Find device and notify thread has already started!");
            return;
        }

        _findAndNotifyThread = new Thread(() -> {
            // This first checks if the PCL Status change was because a device was unplugged or
            // if the PCL disconnect occurred for another reason (i.e. reboot etc.)
            if (getPortNames(PORT_PATH_LINUX, PORT_NAMES_LINUX).contains(originalPort)) {
                LogLine("PCL status changed but device is still present!");
                // Need to wait for the PCL status to change back to TRUE
                // or we need to wait for teh device to disappear
                while (getPortNames(PORT_PATH_LINUX, PORT_NAMES_LINUX).contains(originalPort)) {
                    // If the originalPort never disappears and the PCL status returns to active then
                    // this whole process is no longer required
                    if (PPPchannel.status().equals(StatusCode.CompanionConnected)) {
                        LogLine("Device was never removed and PCL is connected again!");
                        return;
                    }

                    try {
                        //noinspection BusyWait
                        sleep(500);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }

            LogLine("Device is disconnected, stop the PCL and look for a new device");
            // In theory the port will change, therefore, we need to stop the PCL before we can activate
            // a new device/port
            LogLine("Stopping the PCL...");
            PPPchannel.stop();
            LogLine("Finishing stopping the PCL!");

            List<String> portNames;

            do {
                portNames = getPortNames(PORT_PATH_LINUX, PORT_NAMES_LINUX);
                LogLine("Found Device(s): " + ((portNames.size() > 0) ? portNames.toString() : "None!"));
                if (portNames.size() < 1) {
                    try {
                        //noinspection BusyWait
                        sleep(500);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            } while (portNames.size() < 1);

            if (mListner != null) {
                LogLine("Found device and throwing event!");
                mListner.onDeviceFound(portNames.get(0));
            }
        });
        _findAndNotifyThread.setDaemon(true);
        _findAndNotifyThread.start();
    }

    public static List<String> getPortNames(String path, Pattern pattern) {
        path = (path.equals("") ? path : (path.endsWith("/") ? path : path + "/"));
        List<String> retList = new ArrayList<>();
        // TODO only return a list of Ingenico devices

        File dir = new File(path);
        if (dir.exists() && dir.isDirectory()) {
            File[] files = dir.listFiles();
            if (files != null && files.length > 0) {
                for (File file : files) {
                    if (!file.isDirectory() && !file.isFile() && pattern.matcher(file.getName()).find()) {
                        // retList.add(path + file.getName());
                        retList.add(file.getName());
                    }
                }
            }
        }
        return retList;
    }
    
}
