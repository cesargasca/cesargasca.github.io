package org.ingenico.service.pcl;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

public class Utilities {
    public static final List<String> _CmdLineHelp = new ArrayList<>(Arrays.asList(
            "************************* Selection Menu *************************",
            "Start  - Start PCL",
            "Stop   - Stop PCL",
            "Status - PCL Status",
            "Loop   - Update PCL Status Changes",
            "Exit   - Exit Application",
            "******************************************************************"
    ));

    private static final String _systemType = System.getProperty("os.name");
    // MAC: Mac OS X
    // Windows:
    // Linux:

    private static final PCL_Implementation mPclImp = PCL_Implementation.INSTANCE;

    public static void CommandLineInput() {
        Scanner scanner = new Scanner(System.in);
        String req = scanner.next().toUpperCase(Locale.US);

        switch (req) {
            case "H": {
                LogPrompt(_CmdLineHelp);
            }   break;
            case "START": {
                if (mPclImp.PclActive()) {
                    LogLine("PCL Already Started!");
                    return;
                }
                Scanner scannerPort = new Scanner(System.in);

                LogLine("--------------------------------------------------");
                LogLine("OS is " + _systemType);

                if (_systemType.equalsIgnoreCase("Mac OS X")) {
                    LogLine("Enter Device Port Number (do not include the /dev/)");
                } else if (_systemType.equalsIgnoreCase("Windows")) {
                    LogLine("Enter Device Communication Port Number of Address");
                } else if (_systemType.equalsIgnoreCase("Linux")) {
                    LogLine("Enter Device Port Number (do not include the /dev/)");
                } else {
                    LogLine("Enter Device Communication Port Number or Address");
                }

                String devicePort = scannerPort.next();

                LogLine("--------------------------------------------------");
                LogLine("Enter Prxy Port Number: ");
                scannerPort = new Scanner(System.in);
                String scanPort = scannerPort.next();

                if (isNumeric(scanPort)) {
                    LogLine("--------------------------------------------------");
                    LogLine("0 - From ECR to Device");
                    LogLine("1 - From Device to ECR");
                    LogLine("Enter Direction Number: ");
                    scannerPort = new Scanner(System.in);
                    String scanDirection = scannerPort.next();

                    mPclImp.StartPCL(devicePort, Integer.parseInt(scanPort), Integer.parseInt(scanDirection));
                    return;
                }

                LogLine("Enter a valid port number!");
                LogPrompt(_CmdLineHelp);
            }   break;
            case "STOP": {
                mPclImp.StopPCL();
            }   break;
            case "STATUS": {
                boolean status = mPclImp.PclActive();
                LogLine("Companion Connected = " + status);
            }   break;
            case "LOOP": {
                //mPclImp.PclStatusLoop();
            }   break;
            case "EXIT":
            case "Q": {
                LogLine("Existing Application...");
                System.exit(0);
            }   break;

            default: {
                LogLine("Invalid Value = " + req);
            }
        }
    }

    @SuppressWarnings("SameParameterValue")
    static void Sleep(Integer ms) {
        try {
            Thread.sleep(ms);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void LogLine(String logData) {
        System.out.println(getTime() + logData);
    }

    public static synchronized void LogPrompt(List<String> logList) {
        for (String logData : logList) {
            System.out.println(getTime() + logData);
        }
    }

    private static boolean isNumeric(String str) {
        return str.matches("-?\\d+(\\.\\d+)?");  //match a number with optional '-' and decimal.
    }

    private static String getTime() {
        Date dateObj = new Date();
        return "[" + mDF.format(dateObj) + "] ";
    }
    private static final DateFormat mDF = new SimpleDateFormat("HH:mm:ss:SSS");

}
