//
//  TransactionIn.h
//  PclMacOS
//
//  Created by Pierre MONOD-BROCA on 16/12/2016.
//  Copyright © 2016 Ingenico. All rights reserved.
//
/*!
    @file       TransactionIn.h
    @brief      Header file of objective-c class TransactionIn
*/

#import <Foundation/Foundation.h>

/** Represents transaction parameters */
@interface TransactionIn : NSObject

/** Set transaction amount.
 @param amount  Amount in the smaller currency used for the transaction, only 8 digits are used
 @return true if the method succeeded, false if the method failed. */
- (bool) setAmount:(char *)amount;
/** Get amount used for transaction.
 @return amount in the smaller currency used for the transaction, limited to 8 digits. */
- (char *) amount;

/** Set terminal number.
 @param termNum  Terminal number, only 2 digits are used
 @return true if the method succeeded, false if the method failed. */
- (bool) setTermNum:(char *)termNum;
/** Get terminal number.
 @return Terminal number, only 2 digits are used*/
- (char *) termNum;

/** Set transaction currency code.
 @param currencyCode  Currency code for the transaction (see <a href="http://www.iso.org/iso/home/standards/currency_codes.htm">ISO 4217</a>)
 @return true if the method succeeded, false if the method failed. */
- (bool) setCurrencyCode:(char *)currencyCode;
/** Get currency code used for transaction.
 @return currency code for the transaction (See <a href="http://www.iso.org/iso/home/standards/currency_codes.htm">ISO 4217</a>) */
- (char *) currencyCode;

/** Set transaction operation.
 @param operation  Request type for the transaction
 @return true if the method succeeded, false if the method failed. */
- (bool) setOperation:(char *)operation;
/** Get transaction operation.
 @return Request type for the transaction */
- (char *) operation;

/** Specify whether the payment application must call the
 authorization center:
 - ì1î to force the payment application to call the authorization center
 - ì2î to let the payment application decide whether to call the authorization center or not
 @param type  Authorization type for the transaction
 @return true if the method succeeded, false if the method failed. */
- (bool) setAuthorizationType:(char *)type;
/** Get Authorization type.
 @return Authorization type for the transaction*/
- (char *) authorizationType;

/** Set transaction check control.
 @param ctrlCheque  Check control for the transaction
 @return true if the method succeeded, false if the method failed.  */
- (bool) setCtrlCheque:(char *)ctrlCheque;
/** Get transaction check control.
 @return  Check control for the transaction*/
- (char *) ctrlCheque;

/** Set transaction user data.
 @param data  User data, only 10 characters are used
 @return true if the method succeeded, false if the method failed.   */
- (bool) setUserData1:(char *)data;
/** Get transaction user data.
 @return User data*/
- (char *) userData1;

@end
