import com.fazecast.jSerialComm.SerialPort;
import org.junit.Test;

public class SerialTest {
    //http://fazecast.github.io/jSerialComm/

    @Test
    public void getComPortsComm(){
        SerialPort[] ports = SerialPort.getCommPorts();
        System.out.println("\nAvailable Ports:\n");
        for (int i = 0; i < ports.length; ++i)
            System.out.println("   [" + i + "] " + ports[i].getSystemPortName() + " (" + ports[i].getSystemPortPath() + "): " + ports[i].getDescriptivePortName() + " - " + ports[i].getPortDescription() + " @ " + ports[i].getPortLocation() + " (VID = " + String.format("%x",ports[i].getVendorID()) + ", PID = " + String.format("%x",ports[i].getProductID()) + ", Serial = " + ports[i].getSerialNumber() + ")");
    }

    @Test
    public void getVidPidByCom(){
        SerialPort port = SerialPort.getCommPort("COM41");
        System.out.println("Port: " + port.getSystemPortName() +  " (VID = " + String.format("%x",port.getVendorID()) + ", PID = " + String.format("%x",port.getProductID()) + ")");
    }

}
