package org.ingenico.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Config {
    private String address;
    private int direction;
    private int port;
    //private String logLevel;
    private LogConfig log;
    //TODO configure MAX_TRIES
    public Config(int port,int direction,LogConfig logLevel){
        this.direction = direction;
        this.log = logLevel;
    }

}
