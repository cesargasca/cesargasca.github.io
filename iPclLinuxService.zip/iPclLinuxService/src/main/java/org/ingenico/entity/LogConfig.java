package org.ingenico.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class LogConfig {
    private String level;
    private String maxFileSize;
    private String maxLogFiles;

}
