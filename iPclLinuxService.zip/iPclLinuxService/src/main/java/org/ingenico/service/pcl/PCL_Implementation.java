package org.ingenico.service.pcl;

import com.ingenico.ipclbridge.Device;
import com.ingenico.ipclbridge.PPPchannel;
import com.ingenico.ipclbridge.ResultCode;
import com.ingenico.ipclbridge.StatusCode;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class PCL_Implementation {

    private static final Logger logger =  LogManager.getLogger(PCL_Implementation.class);
    public final static PCL_Implementation INSTANCE = new PCL_Implementation();

    public PCL_Implementation() {
        // Used to protect against instance creation
    }

    public boolean StartPCL(String commPort, int port, int direction) {
        logger.debug("STARTING PCL ON [{}]",port);

        if (!activateSpecificDevice(commPort)) {
            logger.error("FAILED TO ACTIVATE [{}]",commPort);
            return false;
        }


        if (!startPppChannel()) {
            logger.error("FAILED TO START PPP CHANNEL");
            return false;
        }

        if (!waitForPppChannel()) {
            logger.error("PPP CHANNEL TIMEOUT");
            return false;
        }

        PPPchannel.Direction dir = PPPchannel.Direction.ToDevice;
        if (direction == 1) {
            dir = PPPchannel.Direction.FromDevice;
        }

        return addPppChannelPort(port, dir);
    }

    public boolean PclActive() {
        return PPPchannel.status().equals(StatusCode.CompanionConnected);
    }


    private static String _deviceAddress = "ttyACM0";


    private boolean activateSpecificDevice(String address) {
        logger.debug("ACTIVATING DEVICE [" + address + "]");
        // TODO need to get these details from the PORT
        _deviceAddress = address;
        Device device = Device.createDevice(Device.Type.USB, address, "LINK2500-00000000");
        return activateFirstDevice(device);
    }

    private boolean activateFirstDevice(Device device) {
        ResultCode resultCode = device.activate();
        if (!resultCode.equals(ResultCode.Success)) {
            logger.error("FAILED TO ACTIVATE DEVICE ERROR = {} ",resultCode);
            return false;
        }
        logger.debug("DEVICE ACTIVATED");
        return true;
    }

    private boolean startPppChannel() {
        logger.debug("STARTING PPP CHANNEL");
        ResultCode resultCode = PPPchannel.start();
        if (!resultCode.equals(ResultCode.Success)) {
            logger.error("FAILED TO START PP CHANNEL ERROR= {}",resultCode);
            return false;
        }
        logger.debug("PPP CHANEL STARTED");
        return true;
    }

    private boolean waitForPppChannel() {
        logger.debug("WAITING FOR PPP CHANNEL");
        final int maxSleep = 10000;
        final int sleepMs = 1000;
        int totalSleep = 0;

        while (!PPPchannel.status().equals(StatusCode.CompanionConnected)) {
            logger.debug("PPP CHANNEL STATUS= " + PPPchannel.status());
            try {
                Thread.sleep(sleepMs);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
            if (totalSleep > maxSleep) {
                logger.debug("MAX TRIES REACHED");
                StopPCL();
                return false;
            }
            totalSleep += sleepMs;
        }
        return true;
    }

    private boolean addPppChannelPort(int port, PPPchannel.Direction direction) {
        logger.debug("CREATING CHANNEL ON PORT [{}]",port);
        ResultCode resultCode = PPPchannel.add(port, direction);
        if (!resultCode.equals(ResultCode.Success)) {
            logger.debug("FAILED TO CREATE CHANNEL ON PORT [{}] WITH ERROR [{}] ",port,resultCode);
            StopPCL();
            return false;
        }

        logger.debug("CREATED PPP CHANNEL ON PORT [{}]",port);
        return true;
    }

    public boolean StopPCL() {
        boolean status = PPPchannel.stop().equals(ResultCode.Success);
        logger.debug("STOP PCL {}",status ? "SUCCESSFUL" : "UNSUCCESSFUL");
        return status;
    }

}