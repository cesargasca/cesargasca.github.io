package org.ingenico.service;

import com.fazecast.jSerialComm.SerialPort;
import com.ingenico.ipclbridge.Device;
import org.ingenico.entity.Config;

import java.util.List;

public interface PclService {
    public void start();
    public void stop();
    public void status();
    /**
     * Scans available Serial Ports sending ATI message to communicate with port.
     *
     * @deprecated use {@link #scanSerial()} ()} instead.
     */
    @Deprecated
    public Device scan();
    public List<SerialPort> scanSerial();
    public SerialPort getFirstSerialDevice();
    public boolean anyDeviceConnected();

}
