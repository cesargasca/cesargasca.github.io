#ifndef LOOPDIALOG_H_
#define LOOPDIALOG_H_

void loopStartStop(void);
void loopGetFullSN(void);
void loopDoTransaction(void);

#endif /* LOOPDIALOG_H_ */