#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <vector>
#include "Printer.h"

#include "pdaUtil.h"
#include <iconv.h>
#include <iostream>
#include <fstream>
#include "mstream.h"

using namespace std;

static void printErrorStatus()
{
    char result;
    if (getPrinterStatus(&result)) {
        sout << "Reason: ";
        if (result & 0x10) {
            sout << "PRINTER ERROR; " << endl;
        }
        if (result & 0x20) {
            sout << "PAPER OUT; " << endl;
        }
        if (result & 0x40) {
            sout << "PRINTER NOT CONNECTED; " << endl;
        }
        if (result & 0x80) {
            sout << "PRINTER BATTERY LOW; " << endl;
        }
        if (result & 0x01) {
            sout << "OTHER ERROR; " << endl;
        }
    }
}

void printTextCmd()
{
    char result;
    openPrinter(&result);

    if (result == 0)
    {
        printText("Message to print", &result);
        if (result == 0)
        {
            sout << "PRINT TEXT OK" << endl;
        }
        else
        {
            sout << "PRINT TEXT KO" << endl;
            printErrorStatus();
        }

        closePrinter(&result);
        if (result != 0)
        {
            sout << "CLOSE PRINTER KO" << endl;
        }
    }
    else
    {
        sout << "OPEN PRINTER KO" << endl;
    }
}

void printBitmapCmd()
{

    char result = '1';

    openPrinter(&result);

    if (result == 0)
    {
        ifstream image;
        image.open("logo_313x128_monochrome_OK.bmp");
        if (image.good())
        {
            image.seekg(0, ios::end);
            int n = image.tellg();
            image.seekg(0, ios::beg);

            char *res = new char[n];
            memset(res, 0, n);

            image.read(res, n);

            image.close();

            printBitmap(res, (unsigned int)n, &result);

            delete res;
        }
        else
        {
            result = '1';
        }

        if (result == 0)
        {
            sout << "PRINT BITMAP OK" << endl;
        }
        else
        {
            sout << "PRINT BITMAP KO" << endl;
            printErrorStatus();
        }

        closePrinter(&result);
    }
    else
    {
        sout << "PRINT BITMAP KO" << endl;
    }
}

void storeLogoCmd()
{
    char result;

    ifstream image;
    image.open("logo_313x128_monochrome_OK.bmp");
    if (image.good())
    {
        image.seekg(0, ios::end);
        int n = image.tellg();
        image.seekg(0, ios::beg);

        char *res = new char[n];
        for (int i = 0; i < n; i++)
            res[i] = '5';

        image.eof();

        image.read(res, n);
        image.close();

        if (storeLogo("LOGO", 0, res, n, &result))
        {
            if (result == 0)
            {
                sout << "STORE LOGO OK" << endl;
            }
            else
            {
                sout << "STORE LOGO KO" << endl;
            }
        }
        else
        {
            sout << "STORE LOGO KO" << endl;
        }
        delete [] res;
    }
    else
    {
        sout << "STORE LOGO KO" << endl;
        result = '1';
    }
}

void printLogoCmd()
{
    char result;

    openPrinter(&result);

    if (result == 0)
    {

        if (printLogo("LOGO", &result))
        {
            if (result == 0)
            {
                sout << "PRINT LOGO OK" << endl;
            }
            else
            {
                sout << "PRINT LOGO KO" << endl;
                printErrorStatus();
            }
        }
        else
        {
            sout << "PRINT LOGO KO" << endl;
        }

        closePrinter(&result);
    }
    else
    {
        sout << "PRINT LOGO KO" << endl;
    }
}

void printStatusCmd()
{
    char strResult;
    char resultP;

    openPrinter(&resultP);

    if (resultP == 0)
    {

        if (getPrinterStatus(&strResult))
        {

            if (strResult & 0x10)
            {
                sout << "PRINTER ERROR;" << endl;
            }
            else if (strResult & 0x20)
            {
                sout << "PAPER OUT; " << endl;
            }
            else if (strResult & 0x40)
            {
                sout << "PRINTER NOT CONNECTED; " << endl;
            }
            else if (strResult & 0x80)
            {
                sout << "PRINTER BATTERY LOW; " << endl;
            }
            else if (strResult & 0x01)
            {
                sout << "OTHER ERROR; " << endl;
            }
            else
            {
                sout << "PRINTER OK; " << endl;
            }
        }
        else
        {
            sout << "GET PRINTER STATUS KO" << endl;
        }

        closePrinter(&resultP);
    }
    else
    {
        sout << "OPEN PRINTER KO" << endl;
    }
}

static bool printTextWithFont(eFonts pFont, char* pText)
{
    char result;
    bool ret = false;
    BOOL bReturn;
    bReturn = openPrinter(&result);

    if (bReturn && result == 0) {
        bReturn = setPrinterFont(pFont, &result);
        if (bReturn && result == 0) {
            bReturn = printText(pText, &result);
            if (bReturn && result == 0) {
                ret = true;
            }
        }

        closePrinter(&result);
    }

    return ret;
}

void printFontTextCmd()
{
    //ISO8859_1
    // "English: Welcome\n"
    if (!printTextWithFont(ISO8859_1, "\x45\x6e\x67\x6c\x69\x73\x68\x3a\x20\x57\x65\x6c\x63\x6f\x6d\x65\x0a")) {
        sout << "Print ISO8859_1 font KO" << endl;
    } else {
        sout << "Print ISO8859_1 font OK" << endl;
    }

    //ISO8859_2
    //"Czech: Nechť již hříšné saxofony ďáblů rozzvučí síň úděsnými tóny waltzu, tanga a quickstepu.\nPolish: Pożądany\n"
    if (!printTextWithFont(ISO8859_2, "\x43\x7a\x65\x63\x68\x3a\x20\x4e\x65\x63\x68\xbb\x20\x6a\x69\xbe\x20\x68\xf8\xed\xb9\x6e\xe9\x20\x73\x61\x78\x6f\x66\x6f\x6e\x79\x20\xef\xe1\x62\x6c\xf9\x20\x72\x6f\x7a\x7a\x76\x75\xe8\xed\x20\x73\xed\xf2\x20\xfa\x64\xec\x73\x6e\xfd\x6d\x69\x20\x74\xf3\x6e\x79\x20\x77\x61\x6c\x74\x7a\x75\x2c\x20\x74\x61\x6e\x67\x61\x20\x61\x20\x71\x75\x69\x63\x6b\x73\x74\x65\x70\x75\x2e\x20\x50\x6f\x6c\x69\x73\x68\x3a\x20\x50\x6f\xbf\xb1\x64\x61\x6e\x79\x0a")) {
        sout << "Print ISO8859_2 font KO" << endl;
    } else {
        sout << "Print ISO8859_2 font OK" << endl;
    }

    //ISO8859_3
    // "Turkish: Günaydin\n"
    if (!printTextWithFont(ISO8859_3, "\x54\x75\x72\x6b\x69\x73\x68\x3a\x20\x47\xfc\x6e\x61\x79\x64\x69\x6e\x0a")) {
        sout << "Print ISO8859_3 font KO" << endl;
    } else {
        sout << "Print ISO8859_3 font OK" << endl;
    }

    //ISO8859_5
    // "Russian: ДОБРО ПОЖАЛОВАТЬ\n"
    if (!printTextWithFont(ISO8859_5, "\x52\x75\x73\x73\x69\x61\x6e\x3a\x20\xb4\xbe\xb1\xc0\xbe\x20\xbf\xbe\xb6\xb0\xbb\xbe\xb2\xb0\xc2\xcc\x0a"))
    {
        sout << "Print ISO8859_5 font KO" << endl;
    }else {
        sout << "Print ISO8859_5 font OK" << endl;
    }

    // //ISO8859_6
    // memset(text, 0, 256);

    // text[0] = 0xC7;
    // text[1] = 0xE4;
    // text[2] = 0xD3;
    // text[3] = 0xE4;
    // text[4] = 0xC7;
    // text[5] = 0xE5;
    // text[6] = 0x20;
    // text[7] = 0xD9;
    // text[8] = 0xE4;
    // text[9] = 0xEA;
    // text[10] = 0xE3;
    // text[11] = 0xE5;
    // text[12] = '\n';

    // printTextWithFont(ISO8859_1,"Arabic:\n");
    // if (!printTextWithFont(ISO8859_6, text)) {
    //    sout << "Print ISO8859_6 font KO" << endl;
    // } else {
    //    sout << "Print ISO8859_6 font OK" << endl;
    // }

    //ISO8859_7
    // "Greek: καλημέρα\n","Greek"
    if (!printTextWithFont(ISO8859_7, "\x47\x72\x65\x65\x6b\x3a\x20\xea\xe1\xeb\xe7\xec\xdd\xf1\xe1\x0a")) {
        sout << "Print ISO8859_7 font KO" << endl;
    } else {
        sout << "Print ISO8859_7 font OK" << endl;
    }

    //ISO8859_15
    // "French: Bienvenue €\n"
    if (!printTextWithFont(ISO8859_15, "\x46\x72\x65\x6e\x63\x68\x3a\x20\x42\x69\x65\x6e\x76\x65\x6e\x75\x65\x20\xa4\x0a")) {
        sout << "Print ISO8859_15 font KO" << endl;
    }else {
        sout << "Print ISO8859_15 font OK" << endl;
    }
}
