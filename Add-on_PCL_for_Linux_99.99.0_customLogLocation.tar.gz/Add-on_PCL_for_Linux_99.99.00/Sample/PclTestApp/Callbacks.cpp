#include <iostream>
#include <fstream>
#include <string>
#include <array>
#include <vector>
#include "pdaUtil.h"
#include "mstream.h"

using namespace std;

void PrintText(char *szText, unsigned char font, unsigned char justification, unsigned char xFactor, unsigned char yFactor, unsigned char pUnderline, unsigned char bold,
	       unsigned char charset)
{
    string bold_on = "", bold_off = "";
    if (bold)
    {
		bold_on = "\e[1m";
		bold_off = "\e[0m";
    }
    sout << "Callback printText: " << endl;
    sout << bold_on << szText << bold_off << endl;
}

void PrintImage(unsigned long width, unsigned long height, char *image, unsigned long size, unsigned char justification)
{
    sout << "Callback printImage: " << endl;
    string file_tmp = "/tmp/tmp_print_img.bmp";
    ofstream ofs(file_tmp, std::ofstream::binary);
    if (!ofs.bad())
    {
		unsigned int _bitmapHeaderSize = 54;
		unsigned int _colorpalettesize = 8;
		unsigned int _rowSize = width / 8;

		unsigned int _pixelbytesize = _rowSize * height;
		unsigned int _filesize = _pixelbytesize + _bitmapHeaderSize + _colorpalettesize;
		unsigned int _offsetsize = _bitmapHeaderSize + _colorpalettesize;

		//------------------ BMP Header ------------------
		//ID (2 bytes)
		ofs.write(array<char, 2>({0x42, 0x4d}).data(), 2);
		//Size of the BMP file (4 bytes)
		ofs.write(reinterpret_cast<const char *>(&_filesize), 4);
		//Application specific (4 bytes)
		ofs.write(array<char, 4>({0, 0, 0, 0}).data(), 4);
		//Offset where the pixel array (bitmap data) can be found (4 bytes)
		ofs.write(reinterpret_cast<const char *>(&_offsetsize), 4);

		//------------------ DIB Header ------------------
		//Number of bytes in the DIB header (4 bytes)
		ofs.write(array<char, 4>({0x28, 0, 0, 0}).data(), 4);
		//Width of the bitmap in pixels (4 bytes)
		ofs.write(reinterpret_cast<const char *>(&width), 4);
		//Height of the bitmap in pixels (4 bytes)
		ofs.write(reinterpret_cast<const char *>(&height), 4);
		//Number of color planes being used (2 bytes)
		ofs.write(array<char, 2>({1, 0}).data(), 2);
		// 	Number of bits per pixel (2 bytes)
		ofs.write(array<char, 2>({1, 0}).data(), 2);
		//BI_RGB, no pixel array compression used (4 bytes)
		ofs.write(array<char, 4>({0, 0, 0, 0}).data(), 4);
		//Size of the raw bitmap data (4 bytes)
		ofs.write(reinterpret_cast<const char *>(&_pixelbytesize), 4);
		int tmp_header_size = 0x130B;
		//Print resolution of the image (0x130B = 72 DPI) (4 bytes)
		ofs.write(reinterpret_cast<const char *>(&tmp_header_size), 4);
		//Print resolution of the image (0x130B = 72 DPI) (4 bytes)
		ofs.write(reinterpret_cast<const char *>(&tmp_header_size), 4);
		//Number of colors in the palette (4 bytes)
		ofs.write(array<char, 4>({0, 0, 0, 0}).data(), 4);
		//0 means all colors are important (4 bytes)
		ofs.write(array<char, 4>({0, 0, 0, 0}).data(), 4);

		//------------------ Color table ------------------
		ofs.write(array<char, 8>({0, 0, 0, 0, static_cast<char>(0xFF), static_cast<char>(0xFF), static_cast<char>(0xFF), 0}).data(), 8);

		//------------------ Pixel Data ------------------
		vector<char> tmp_image(size, 0);
		for (int i = height - 1, j = 0; i >= 0; --i, ++j)
		{
			for (int h = 0; h < _rowSize; ++h)
			{
				tmp_image[(j * _rowSize) + h] = 0xFF - image[(i * _rowSize) + h];
			}
		}

		ofs.write(tmp_image.data(), size);
		ofs.flush();
		ofs.close();

		//view with eog save image
		string cmd = "eog ";
		cmd.append(file_tmp);
		cmd.append("& > /dev/null 2>&1");
		system(cmd.c_str());
    }
}

void FeedPaper(DWORD dwLines)
{
    sout << "Callback feedPaper: " << dwLines << endl;
}

void CutPaper()
{
    sout << "Callback cutPaper " << endl;
}

int StartReceipt(unsigned char type)
{
    sout << "Callback: ********** StartReceipt ***********" << endl;
    return 0;
}

int EndReceipt()
{
    sout << "Callback: ********** EndReceipt ***********" << endl;
    return 0;
}

void AddSignature()
{
    sout << "Callback: addSignature" << endl;
}

int SignatureCapture(int width, int height, int timeout, unsigned char *data, unsigned long *dataSize)
{
    sout << "Callback: Signature capture" << endl;
    int ret = 1;
    ifstream ifs("sign_sample.bmp", ios::binary | ios::ate);
    if (!ifs.bad())
    {
		int length = ifs.tellg();
		if (length <= *dataSize)
		{
			ifs.seekg(0, ios::beg);
			ifs.read(data, length);
			ifs.close();
			*dataSize = length;
			ret = 0;
		}
    }
    return ret;
}

void BarcodeEventExt(char *data, int len, char *symb, int len_symb)
{
    int symbo = bcrCodeUDSIToSymbology(symb);
    sout << "Callback barcode data: " << data << " and symbology: " << bcrSymbologyToText(symbo) << endl;
}

void BarcodeEvent(char *data, int len)
{
    sout << "Callback barcode data: " << data << endl;
}

void BarcodeEventClose()
{
    sout << "Callback Barcode close" << endl;
}