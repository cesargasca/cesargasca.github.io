#include <iostream>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <vector>
#include "TMS.h"
#include "pdaUtil.h"
#include "mstream.h"

using namespace std;

void doUpdateCmd()
{
    unsigned long lResult;
    if (doUpdate(&lResult)) {
        if (lResult == 0) {
            sout << "DO UPDATE OK" << endl;
        } else {
            sout << "DO UPDATE KO" << endl;
        }
    } else {
        sout << "DO UPDATE KO" << endl;
    }
}

void tmsReadParametersCmd()
{
    char addr[258] = { 0 };
    char port[256] = { 0 };
    char identifier[256] = { 0 };
    tms_ssl_parameter_t sslProfiles;
    char result;

    if (tmsReadParam(addr, sizeof(addr), port, sizeof(port), identifier, sizeof(identifier), &sslProfiles, &result)) {
        if (result == 0) {
            sout << "TMS READ OK" << endl;
            sout << "ADDRESS: " << addr << endl;
            sout << "PORT: " << port << endl;
            sout << "IDENTIFIER: " << identifier << endl;
            sout << sslProfiles.nb_ssl_profile << " ssl profiles" << endl;
            for (int i = 0; i < sslProfiles.nb_ssl_profile; i++) {
                sout << sslProfiles.ssl_profiles[i] << endl;
            }
            sout << "CURRENT SSL PROFILE: " << sslProfiles.current_ssl_profile << endl;
        } else {
            sout << "TMS READ KO" << endl;
        }
    } else {
        sout << "TMS READ KO" << endl;
    }
}

static void tmsWriteParametersCmd(char* addr, char* port, char* id, char* ssl)
{
    char result;

    if (tmsWriteParam(addr, port, id, ssl, &result)) {
        if (result == 0) {
            sout << "TMS WRITE OK" << endl;
        } else {
            sout << "TMS WRITE KO" << endl;
        }
    } else {
        sout << "TMS WRITE KO" << endl;
    }
}

void tmsWriteParametersT2Cmd()
{
    tmsWriteParametersCmd("83.206.130.148", "12247", "888390201", NULL);
}

void tmsWriteParametersT3Cmd()
{
    tmsWriteParametersCmd("83.206.130.148", "12247", "888390101", NULL);
}
