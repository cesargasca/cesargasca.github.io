#include <iostream>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <limits>
#include "LoopDialog.h"
#include "pdaUtil.h"
#include "mstream.h"

using namespace std;

#define TIMEOUT_CONNECTION 100


void loopStartStop(void)
{
    int nbLoop = 0;
    int cptTest = 0;
    int cptSuccess = 0;
    int timeoutServerStatus = 0;
    char result = 0U;

    sout << "Entry a number of loop: " << endl;
    while (!(cin >> nbLoop)) {
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
        sout << "Invalid input.  Try again: " << endl;
    }
    sout << endl;
    sout << "Test processing..." << endl;

    for(int i = 0; i < nbLoop; i++)
    {
        cptTest++;
        
        if(startPclService())
        {
            bool bReturn = false;
            while((timeoutServerStatus < TIMEOUT_CONNECTION)&&((bReturn == false) || (result == 0U))){
                bReturn = serverStatus(&result);
                timeoutServerStatus++;
                usleep(500000);
            }
            if(stopPclService())
            {
                if(timeoutServerStatus < TIMEOUT_CONNECTION)
                {
                    cptSuccess++;
                }
            }
        }
        else
        {
            stopPclService();
        }
        usleep(500000);
    }
    sout << endl;
    sout << "Test Start/Stop OK : " << cptSuccess << " / " << cptTest << endl;
}

void loopGetFullSN(void)
{
    char fullSerial[128];
    int cptTest = 0;
    int cptSuccess = 0;
    int nbLoop = 0;
    int timeoutServerStatus = 0;
    char result = 0U;

    stopPclService();

    sout << "Entry a number of loop: " << endl;
    while (!(cin >> nbLoop)) {
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
        sout << "Invalid input.  Try again: " << endl;
    }
    sout << endl;

    if(startPclService())
    {
        bool bReturn = false;
        while((timeoutServerStatus < TIMEOUT_CONNECTION)&&((bReturn == false) || (result == 0U))){
            bReturn = serverStatus(&result);
            timeoutServerStatus++;
            usleep(500000);
        }

        if(timeoutServerStatus < TIMEOUT_CONNECTION)
        {
            sout << "Test processing..." << endl;
            for(int i = 0; i < nbLoop; i++)
            {
                cptTest++;
                sout << "\rN = " << cptTest << "         ";

                if(getFullSerialNumber(fullSerial, sizeof(fullSerial)))
                {
                    cptSuccess++;
                }
                usleep(500000);
            }
            sout << "\rTest Get Full SN OK : " << cptSuccess << " / " << cptTest << endl;
        }
        else
        {
            sout << "Connexion Timeout" << endl;
        }
    }
    else
    {
        sout << "PCL Service not started" << endl;
    }
    
    stopPclService();
}

void loopDoTransaction(void)
{
    int nbLoop = 0;
    int cptTest = 0;
    int cptSuccess = 0;
    char result = 0U;
    int timeoutServerStatus = 0;

    stopPclService();

    sout << "Entry a number of loop: " << endl;
    while (!(cin >> nbLoop)) {
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
        sout << "Invalid input.  Try again: " << endl;
    }
    sout << endl;

    if(startPclService())
    {
        bool bReturn = false;
        while((timeoutServerStatus < TIMEOUT_CONNECTION)&&((bReturn == false) || (result == 0U))){
            bReturn = serverStatus(&result);
            timeoutServerStatus++;
            usleep(500000);
        }

        if(timeoutServerStatus < TIMEOUT_CONNECTION)
        {
            sout << "Test processing..." << endl;
            for(int i = 0; i < nbLoop; i++)
            {
                cptTest++;
                sout << "\rN = " << cptTest << "         ";

                ITransactionIn* transactionIn = create_itransactionin();
                if (transactionIn) {

                    ITransactionOut* transactionOut = create_itransactionout();
                    if (transactionOut) {

                        transactionIn->setAmount("995");
                        transactionIn->setTermNum("58");
                        transactionIn->setAuthorizationType("1");
                        transactionIn->setCurrencyCode("978");
                        transactionIn->setOperation("C");
                        transactionIn->setUserData1("");

                        if (doTransaction(transactionIn, transactionOut)) {

                            transactionOut->getAmount();
                            char* errorRes = transactionOut->getC3Error();
                            transactionOut->getCurrencyCode();

                            if (atoi(errorRes) == 0) {
                                cptSuccess++;
                            }

                        }
                        delete transactionOut;
                    }
                }
                delete transactionIn;
                usleep(500000);
            }
            sout << "\rTest Transaction OK : " << cptSuccess << " / " << cptTest << endl;
        }
        else
        {
            sout << "Connexion Timeout" << endl;
        }
    }
    else
    {
        sout << "PCL Service not started" << endl;
    }
    
    stopPclService();

}