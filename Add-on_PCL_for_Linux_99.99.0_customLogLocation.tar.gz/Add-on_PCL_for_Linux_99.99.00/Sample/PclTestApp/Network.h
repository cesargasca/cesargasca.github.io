#ifndef NETWORK_H_
#define NETWORK_H_

void addDynamicBridgeFromTelliumCmd();
void addDynamicBridgeToTelliumCmd();
void addDynamicBridgeFromTelliumOnlyCmd();
void addDynamicBridgeToTelliumOnlyCmd();

#endif /* NETWORK_H_ */
