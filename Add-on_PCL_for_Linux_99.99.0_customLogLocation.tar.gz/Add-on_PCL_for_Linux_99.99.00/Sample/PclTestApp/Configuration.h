#ifndef CONFIGURATION_H_
#define CONFIGURATION_H_

void getInfosCmd();
void getTimeCmd();
void setTimeCmd();
void getFullSerialNumberCmd();
void resetCmd();
void shortcutCmd();
void getSPMCIVersionCmd();
void inputSimulCmd();
void setLockBacklightCmd(int val);
void getTerminalComponentCmd();
void getBatteryLevelCmd();


#endif /* CONFIGURATION_H_ */
