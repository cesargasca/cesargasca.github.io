#include <iostream>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <vector>
#include "Transaction.h"
#include "pdaUtil.h"
#include "mstream.h"

using namespace std;

void doTransactionCmd(char* pAmont)
{

    ITransactionIn* transactionIn = create_itransactionin();
    if (transactionIn) {

        ITransactionOut* transactionOut = create_itransactionout();
        if (transactionOut) {

            transactionIn->setAmount(pAmont);
            transactionIn->setTermNum("58");
            transactionIn->setAuthorizationType("1");
            transactionIn->setCurrencyCode("978");
            transactionIn->setOperation("C");
            transactionIn->setUserData1("");

            if (doTransaction(transactionIn, transactionOut)) {

                char* amountRes = transactionOut->getAmount();
                char* errorRes = transactionOut->getC3Error();
                char* curCodeRes = transactionOut->getCurrencyCode();

                if (atoi(errorRes) == 0) {
                    sout << "Transaction OK " << endl << "Amount: " << amountRes << " error: " << errorRes << " currency: " << curCodeRes << endl;                    
                } else {
                    sout << "Error: " << errorRes << " Transaction KO " << endl;
                }

            } else {
                sout << "DO TRANSACTION KO" << endl;
            }
            delete transactionOut;
        }
    }
    delete transactionIn;
}

#define BUFF_TRANS_SIZE 64*1024

void doTransactionExCmd() {

    unsigned char globBufferOut[BUFF_TRANS_SIZE];
    unsigned long globBufferOutSize = BUFF_TRANS_SIZE;
    unsigned char charBuff[128];

    strcpy((char*)charBuff, "Data extended for DoTransactionExtended");
    unsigned long int sizeBufferIn = strlen((char*)charBuff);

    ITransactionIn *transactionIn;
    transactionIn = create_itransactionin();

    ITransactionOut *transactionOut;
    transactionOut = create_itransactionout();

    transactionIn->setAmount("23456");
    transactionIn->setTermNum("58");
    transactionIn->setAuthorizationType("1");
    transactionIn->setCurrencyCode("978");
    transactionIn->setOperation("C");
    transactionIn->setUserData1("");

    unsigned short int appNumber = 12;

    if(doTransactionEx(transactionIn, transactionOut, appNumber, charBuff, sizeBufferIn , globBufferOut, (unsigned long int *)&globBufferOutSize)) {

		char *amountRes = transactionOut->getAmount();
		char *errorRes = transactionOut->getC3Error();
		char *curCodeRes = transactionOut->getCurrencyCode();

		if(atoi(errorRes) == 1){
			sout << "Error: " << errorRes << " TRANSACTION EX KO " << endl;
		} else {
			sout << "Amount: " << amountRes << " error: " << errorRes << " currency: " << curCodeRes << " extended data: " << globBufferOut << endl;
		}

    } else {
    	sout << "DO TRANSACTION EX KO" << endl;
    }

}
