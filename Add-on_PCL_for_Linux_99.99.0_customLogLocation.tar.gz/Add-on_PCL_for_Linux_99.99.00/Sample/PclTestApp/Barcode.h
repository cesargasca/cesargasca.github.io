#ifndef BARCODE_H_
#define BARCODE_H_

void openBarcodeCmd();
void closeBarcodeCmd();
void startScanCmd();
void stopScanCmd();
void resetBarcodeCmd();
void getFirmwareVersionCmd();
void getSettingsVersionCmd();

void setReadModeCmd();
void setLightingModeCmd();
void setImagerModeCmd();

void setGoodScanBeepCmd();
void setBeepCmd();

void enableDisableTriggerCmd();
void enableSymbologiesCmd();
void disableSymbologiesCmd();
void convertSymbologyToTextCmd();




#endif /* BARCODE_H_ */
