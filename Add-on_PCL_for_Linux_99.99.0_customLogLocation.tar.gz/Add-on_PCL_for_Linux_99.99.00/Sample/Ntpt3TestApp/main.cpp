#include "PclUtilities.h"
#include "fileSharing.h"
#include "pdaUtil.h"
#include <X11/Xlib.h>
#include <glib.h>
#include <gtk/gtk.h>
#include <iostream>
#include <limits>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <string>
#include <unistd.h>
#include <vector>

enum {
    COL_IS_DIR = 0,
    COL_NAME,
    COL_ICON,
    NUM_COLS
};

void writeLog(const char* format, ...);
static int OnList(telium_file_t** files, int number, int result);

typedef struct
{
    GtkWidget* widget;
    std::string text;
} DispatchText;

typedef struct {
    GtkWidget* windows_main;
    GtkWidget* connect_btn;
    GtkWidget* start_btn;
    GtkWidget* disconnect_btn;
    GtkWidget* send_btn;
    GtkWidget* scan_btn;
    GtkWidget* back_btn;
    GtkWidget* pcl_status_text;
    GtkWidget* result_text;
    GtkWidget* folder_path_text;
    GtkWidget* terminal_file_view;
    //file chooser
    GtkWidget* send_file_chooser;
    GtkWidget* download_file_chooser;
    //scan dialog
    GtkWidget* scan_result_dialog;
    GtkWidget* scan_result_box;
} app_widgets;

app_widgets* g_widgets = NULL;
std::string g_currentPath = "", g_distantdownloadfile = "";
GdkPixbuf* g_folderpixbuf = NULL;
GdkPixbuf* g_filepixbuf = NULL;

static gboolean dispatchPCLStatusText(gpointer pdata)
{
    DispatchText* data = (DispatchText*)pdata;
    gtk_label_set_text(GTK_LABEL(data->widget), data->text.c_str());
    delete data;
    return G_SOURCE_REMOVE;
}

void* PclStateThread(gpointer pdata)
{
    char result = 0, last_result = 0;
    BOOL ret = FALSE, last_ret = TRUE;
    GtkWidget* widget = GTK_WIDGET(pdata);

    while (true) {
        if (widget != NULL) {
            if (serverStatus(&result)) {
                if (last_result != result) {
                    last_result = result;
                    if (result == 1) {
                        DispatchText* data = new DispatchText;
                        data->widget = widget;
                        data->text = "PCL connected";
                        gdk_threads_add_idle(dispatchPCLStatusText, data);
                    } else {
                        DispatchText* data = new DispatchText;
                        data->widget = widget;
                        data->text = "PCL disconnected";
                        gdk_threads_add_idle(dispatchPCLStatusText, data);
                    }
                }
            } else {
                if (last_ret != ret) {
                    last_ret = ret;
                    DispatchText* data = new DispatchText;
                    data->widget = widget;
                    data->text = "PCL disconnected";
                    gdk_threads_add_idle(dispatchPCLStatusText, data);
                }
            }
        }
        sleep(1);
    }

    return 0;
}

void clearExplorer()
{
    GtkListStore* store = GTK_LIST_STORE(gtk_tree_view_get_model(GTK_TREE_VIEW(g_widgets->terminal_file_view)));
    if (store != NULL)
        gtk_list_store_clear(store);
}

static gboolean dispatchPathText(gpointer pdata)
{
    DispatchText* data = (DispatchText*)pdata;
    gtk_label_set_text(GTK_LABEL(data->widget), data->text.c_str());
    delete data;
    return G_SOURCE_REMOVE;
}

void updateDisplayPath(std::string path)
{
    DispatchText* data = new DispatchText;
    data->widget = g_widgets->folder_path_text;
    data->text = path;
    gdk_threads_add_idle(dispatchPathText, data);
}

void refreshExplorer(std::string path)
{
    if (PCLFileSharing_currentState() == FILE_SHARING_STATE_CONNECTED) {
        writeLog("Refresh list %s ...", path.c_str());
        updateDisplayPath(path);
        PCLFileSharing_list(path.c_str(), &OnList);
    } else {
        writeLog("Error refresh terminal file, client not connected.");
    }
}

void updateBtnState(int isConnected)
{
    if (g_widgets != NULL) {
        gtk_widget_set_sensitive(g_widgets->connect_btn, !isConnected);
        gtk_widget_set_sensitive(g_widgets->start_btn, !isConnected);
        gtk_widget_set_sensitive(g_widgets->disconnect_btn, isConnected);
        gtk_widget_set_sensitive(g_widgets->send_btn, isConnected);
        gtk_widget_set_sensitive(g_widgets->back_btn, isConnected);
    }

    if (isConnected)
        refreshExplorer(g_currentPath);
    else {
        g_currentPath = "Terminal Path";
        updateDisplayPath(g_currentPath);
        clearExplorer();
    }
}

static gboolean dispatchWriteLog(gpointer pdata)
{
    GtkTextIter iter;
    DispatchText* data = (DispatchText*)pdata;
    GtkTextBuffer* buffer = gtk_text_view_get_buffer(GTK_TEXT_VIEW(data->widget));
    GtkTextMark* mark = gtk_text_buffer_get_insert(buffer);
    gtk_text_buffer_get_iter_at_mark(buffer, &iter, mark);
    data->text += "\n";

    gtk_text_buffer_insert(buffer, &iter, data->text.c_str(), -1);
    gtk_text_view_scroll_to_mark(GTK_TEXT_VIEW(data->widget), mark, 0.0, FALSE, 0.0, 0.0);

    delete data;
    return G_SOURCE_REMOVE;
}

void writeLog(const char* format, ...)
{
    char dest[1024];
    memset(dest, 0, sizeof(dest));
    va_list argptr;
    va_start(argptr, format);
    vsprintf(dest, format, argptr);
    va_end(argptr);

    if (g_widgets != NULL)
    {
        DispatchText *data = new DispatchText;
        if (data)
        {
            data->widget = g_widgets->result_text;
            data->text = dest;
            gdk_threads_add_idle(dispatchWriteLog, data);
        }
        else
        {
            std::cout << dest << std::endl;
        }
    }
    else
    {
        std::cout << dest << std::endl;
    }
}

// Implementation Callback File Sharing
static int OnStart(int result)
{
    if (result == FILESHARING_OK) {
        g_currentPath = "/";
        updateBtnState(1);
        writeLog("Client connected.");
    } else {
        updateBtnState(0);
        writeLog("Connection error %d", result);
    }
    return 0;
}

static int OnStop(int result)
{
    if (result == FILESHARING_OK) {
        updateBtnState(0);
        writeLog("Client disconnected.");
    } else {
        writeLog("disconnection error %d", result);
    }
    return 0;
}

static int OnUpload(int result)
{
    if (result == FILESHARING_OK) {
        writeLog("File successfully uploaded");
    } else {
        writeLog("Error %d during upload", result);
    }
    return 0;
}

static int OnDownload(int result)
{
    if (result == FILESHARING_OK) {
        writeLog("File successfully downloaded");
    } else {
        writeLog("Error %d during downloaded", result);
    }
    return 0;
}

static int OnUploadFiles(int sent, int total, int result)
{
    if (result == FILESHARING_OK) {
        writeLog("%d/%d files successfully uploaded", sent, total);
    } else {
        writeLog("%d/%d files: Error %d during uploaded", sent, total, result);
    }
    return 0;
}

static int OnList(telium_file_t** files, int number, int result)
{
    if (result == FILESHARING_OK) {
        clearExplorer();
        GtkListStore* store = GTK_LIST_STORE(gtk_tree_view_get_model(GTK_TREE_VIEW(g_widgets->terminal_file_view)));
        if (store != NULL) {
            for (int i = 0; i < number; ++i) {
                GtkTreeIter iter;
                GdkPixbuf* icon;

                gtk_list_store_append(store, &iter);
                if (files[i]->isDirectory)
                    icon = g_folderpixbuf;
                else
                    icon = g_filepixbuf;

                gtk_list_store_set(store, &iter, COL_IS_DIR, files[i]->isDirectory, COL_NAME, files[i]->name, COL_ICON, icon, -1);
            }
            writeLog("List files finished");
        } else {
            writeLog("refresh views error");
        }

        //free files pointer after use
        if (files != NULL) {
            for (int i = 0; i < number; ++i) {
                free(files[i]);
            };
            free(files);
            files = NULL;
        }
    } else {
        updateBtnState(0);
        writeLog("List file error %d", result);
    }
    return 0;
}

// Callback IHM
// called when window is closed
extern "C" void on_mainwindow_destroy()
{
    char result;

    if (serverStatus(&result) && result == 1)
        stopPclService();

    gtk_main_quit();
}

extern "C" void on_back_clicked(GtkButton* button, app_widgets* app_wdgts)
{
    int pos = g_currentPath.find_last_of('/');
    if (pos != -1) {
        if (pos == 0) {
            g_currentPath = "/";
        } else {
            g_currentPath = g_currentPath.substr(0, pos);
        }
        refreshExplorer(g_currentPath);
    }
    //do nothing path not initialise
}

extern "C" void on_connect_clicked(GtkButton* button, app_widgets* app_wdgts)
{
    writeLog("Waiting for connection...");

    int port = 7000;
    PCLFileSharing_start(port, TRUE, &OnStart);
}

extern "C" void on_start_do_update_clicked(GtkButton* button, app_widgets* app_wdgts)
{
    writeLog("Waiting for connection and doUpdate...");

    int port = 7000;
    PCLFileSharing_startAndLaunchDoUpdate(port, &OnStart);
}

extern "C" void on_disconnect_clicked(GtkButton* button, app_widgets* app_wdgts)
{
    writeLog("Waiting for client disconnection in progress...");
    PCLFileSharing_stop(&OnStop);
}

extern "C" void on_pcl_start_activate(GtkButton* button, app_widgets* app_wdgts)
{
    if (gtk_switch_get_active(GTK_SWITCH(button))) {
        writeLog("Start PCL service...");
        startPclService();
    } else {
        writeLog("Stop PCL service...");
        stopPclService();
    }
}

extern "C" void on_row_term_file_selected(GtkTreeView* treeview,
    GtkTreePath* path,
    GtkTreeViewColumn* col,
    app_widgets* app_wdgts)
{
    GtkTreeIter iter;
    GtkTreeModel* model = gtk_tree_view_get_model(treeview);
    if (model != NULL && path != NULL && gtk_tree_model_get_iter(model, &iter, path) == TRUE) {
        gboolean isdir;
        gchararray name;
        gtk_tree_model_get(model, &iter, COL_IS_DIR, &isdir, COL_NAME, &name, -1);
        if (isdir) {
            if (g_currentPath.length() == 1) {
                g_currentPath = g_currentPath + name;
            } else {
                g_currentPath = g_currentPath + "/" + name;
            }
            refreshExplorer(g_currentPath);
        } else {
            g_distantdownloadfile = g_currentPath + "/" + name;
            writeLog("Download File %s", g_distantdownloadfile.c_str());

            gtk_file_chooser_set_current_folder(GTK_FILE_CHOOSER(app_wdgts->download_file_chooser), getenv("HOME"));
            gtk_widget_show(app_wdgts->download_file_chooser);
        }

        g_free(name);
    }
}

extern "C" void on_download_file_cancel_clicked(GtkButton* button, app_widgets* app_wdgts)
{
    g_distantdownloadfile = "";
    gtk_widget_hide(app_wdgts->download_file_chooser);
}

extern "C" void on_download_file_ok_clicked(GtkButton* button, app_widgets* app_wdgts)
{
    /* Get all selected filenames: */
    gchar* selected_folder = gtk_file_chooser_get_filename(GTK_FILE_CHOOSER(app_wdgts->download_file_chooser));    
    PCLFileSharing_download(g_distantdownloadfile.c_str(), selected_folder, &OnDownload);

    g_distantdownloadfile = "";
    gtk_widget_hide(app_wdgts->download_file_chooser);
}

//Send file chooser
extern "C" void on_send_file_clicked(GtkButton* button, app_widgets* app_wdgts)
{
    /* Be nice and land on the last visited folder (most of the users prefer this function) */
    gtk_file_chooser_set_current_folder(GTK_FILE_CHOOSER(app_wdgts->send_file_chooser), getenv("HOME"));
    gtk_widget_show(app_wdgts->send_file_chooser);
}

extern "C" void on_send_file_cancel_clicked(GtkButton* button, app_widgets* app_wdgts)
{
    gtk_widget_hide(app_wdgts->send_file_chooser);
}

extern "C" void on_send_file_ok_clicked(GtkButton* button, app_widgets* app_wdgts)
{
    /* Get all selected filenames: */
    GSList* selected_filenames = gtk_file_chooser_get_filenames(GTK_FILE_CHOOSER(app_wdgts->send_file_chooser));
    int countFile = g_slist_length(selected_filenames);
    if (countFile == 1) {
        char* file = (char*)selected_filenames->data;
        writeLog("File Name : %s", file);
        PCLFileSharing_uploadExt(file, "/import", &OnUpload,strstr(file,".gz") != NULL);
    } else {
        bool gzip_compression = false;
        char** files = (char**)malloc(countFile * sizeof(char*));
        for (int i = 0; selected_filenames != NULL; ++i) {
            char* file = (char*)selected_filenames->data;
            int lengthFile = strlen((char*)selected_filenames->data);
            files[i] = (char*)malloc((lengthFile + 1) * sizeof(char));
            strcpy(files[i], file);
            if(strstr(files[i],".gz") != NULL)
                gzip_compression = true;
            selected_filenames = g_slist_next(selected_filenames);
        }

        PCLFileSharing_uploadFilesListExt(files, countFile, "/import", &OnUploadFiles,gzip_compression);

        //free files list
        for (int j = 0; j < countFile; ++j) {
            free(files[j]);
        };
        free(files);
        files = NULL;
    }

    g_slist_free(selected_filenames);

    /* Get rid of the dialog */
    gtk_widget_hide(app_wdgts->send_file_chooser);
}

//Scan dialog
PUSB_COMPANION_INFO pUsbCompanions = NULL;
PUSB_COMPANION_INFO pRs232Companions = NULL;
int g_dwEntriesUsb = 0;
int g_dwEntriesRs232 = 0;

static void clean_result_list(app_widgets* app_wdgts)
{
    if (pUsbCompanions != NULL) {
        free(pUsbCompanions);
        pUsbCompanions = NULL;
    }
    if (pRs232Companions != NULL) {
        free(pRs232Companions);
        pRs232Companions = NULL;
    }
    g_dwEntriesRs232 = 0;
    g_dwEntriesUsb = 0;

    GList* children = gtk_container_get_children(GTK_CONTAINER(app_wdgts->scan_result_box));
    while ((children = g_list_next(children)) != NULL) {
        gtk_widget_destroy(GTK_WIDGET(children->data));
    }
}

extern "C" void on_scan_clicked(GtkButton* button, app_widgets* app_wdgts)
{
    DWORD dwRet = 0, dwSizeRs232 = 0, dwSizeUsb = 0;
    GSList* group = NULL;
    writeLog("Start PCL Scan...");

    //Search USB Terminal
    dwRet = getUSBDevices(NULL, &dwSizeUsb, &g_dwEntriesUsb);
    if (dwRet == ERROR_NOT_ENOUGH_MEMORY && g_dwEntriesUsb > 0) {
        pUsbCompanions = (PUSB_COMPANION_INFO)malloc(dwSizeUsb);
        memset(pUsbCompanions, 0, dwSizeUsb);
        dwRet = getUSBDevices(pUsbCompanions, &dwSizeUsb, &g_dwEntriesUsb);
        for (int i = 0; i < (int)g_dwEntriesUsb; ++i) {
            //add entry in list
            char tmpStr[512];
            memset(tmpStr, 0, sizeof(tmpStr));
            sprintf(tmpStr, "%d - %s (%s) : %s", i, pUsbCompanions[i].szPort, pUsbCompanions[i].szSymbPort, pUsbCompanions[i].szName);
            GtkWidget* radio = gtk_radio_button_new_with_label(group, tmpStr);
            group = gtk_radio_button_get_group(GTK_RADIO_BUTTON(radio));
            gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(radio), pUsbCompanions[i].fActivated);
            gtk_box_pack_start(GTK_BOX(app_wdgts->scan_result_box), radio, TRUE, TRUE, 5);
        }
    }

    //Search RS232 terminal
    dwRet = getRS232Devices(NULL, &dwSizeRs232, &g_dwEntriesRs232);
    if (dwRet == ERROR_NOT_ENOUGH_MEMORY && g_dwEntriesRs232 > 0) {
        pRs232Companions = (PUSB_COMPANION_INFO)malloc(dwSizeRs232);
        memset(pRs232Companions, 0, dwSizeRs232);
        dwRet = getRS232Devices(pRs232Companions, &dwSizeRs232, &g_dwEntriesRs232);
        for (int i = 0; i < (int)g_dwEntriesRs232; ++i) {
            //add entry in list
            char tmpStr[512];
            memset(tmpStr, 0, sizeof(tmpStr));
            sprintf(tmpStr, "%d - %s : %s", i + g_dwEntriesUsb, pRs232Companions[i].szPort, pRs232Companions[i].szName);
            GtkWidget* radio = gtk_radio_button_new_with_label(group, tmpStr);
            group = gtk_radio_button_get_group(GTK_RADIO_BUTTON(radio));
            gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(radio), pRs232Companions[i].fActivated);
            gtk_box_pack_start(GTK_BOX(app_wdgts->scan_result_box), radio, TRUE, TRUE, 5);
        }
    }

    if ((g_dwEntriesRs232 + g_dwEntriesUsb) > 0) {
        gtk_widget_show_all(app_wdgts->scan_result_dialog);
    } else {
        writeLog("No terminal found");
    }
}

extern "C" void on_scan_result_ok_clicked(GtkButton* button, app_widgets* app_wdgts)
{
    GList* children = gtk_container_get_children(GTK_CONTAINER(app_wdgts->scan_result_box));
    while ((children = g_list_next(children)) != NULL) {
        GtkToggleButton* tmp_button = (GtkToggleButton*)children->data;
        if (gtk_toggle_button_get_active(tmp_button)) {
            //Select term
            int numSelect = 0;
            sscanf(gtk_button_get_label(GTK_BUTTON(tmp_button)), "%d -", &numSelect);

            if (numSelect < (int)g_dwEntriesUsb) {
                if (pUsbCompanions[numSelect].szSymbPort[0] != 0 || strlen(pUsbCompanions[numSelect].szSymbPort) != 0) {
                    activateUSBDevice(pUsbCompanions[numSelect].szSymbPort);
                } else {
                    activateUSBDevice(pUsbCompanions[numSelect].szPort);
                }
            } else {
                numSelect = numSelect - g_dwEntriesUsb;
                activateRS232Device(pRs232Companions[numSelect].szPort);
            }
            break;
        }
    }
    clean_result_list(app_wdgts);
    gtk_widget_hide(app_wdgts->scan_result_dialog);
}

extern "C" void on_scan_result_cancel_clicked(GtkButton* button, app_widgets* app_wdgts)
{
    clean_result_list(app_wdgts);
    gtk_widget_hide(app_wdgts->scan_result_dialog);
}

int main(int argc, char* argv[])
{
    XInitThreads();
    gtk_init(&argc, &argv);
    GError* error = NULL;
    GtkIconTheme* icon_theme;

    GtkBuilder* builder = gtk_builder_new();
    if (!gtk_builder_add_from_file(builder, "Ntpt3TestApp.glade", NULL)) {
        g_object_unref(builder);
        std::cerr << "Error to load IHM Ntpt3TestApp.glade" << std::endl;
        return 1;
    }

    //load icon folder and file
    icon_theme = gtk_icon_theme_get_default();
    g_filepixbuf = gtk_icon_theme_load_icon(icon_theme, "text-x-generic", 32, 0, &error);
    if (!g_filepixbuf) {
        g_warning("Couldn’t load icon: %s", error->message);
        g_error_free(error);
        return 1;
    }
    g_folderpixbuf = gtk_icon_theme_load_icon(icon_theme, "folder", 32, 0, &error);
    if (!g_folderpixbuf) {
        g_warning("Couldn’t load icon: %s", error->message);
        g_error_free(error);
        return 1;
    }

    g_widgets = g_slice_new(app_widgets);

    // get pointers to widgets
    g_widgets->windows_main = GTK_WIDGET(gtk_builder_get_object(builder, "mainwindow"));
    g_widgets->connect_btn = GTK_WIDGET(gtk_builder_get_object(builder, "Connect"));
    g_widgets->start_btn = GTK_WIDGET(gtk_builder_get_object(builder, "ConnectDoUpdate"));
    g_widgets->disconnect_btn = GTK_WIDGET(gtk_builder_get_object(builder, "Disconnect"));
    g_widgets->send_btn = GTK_WIDGET(gtk_builder_get_object(builder, "SendFile"));
    g_widgets->back_btn = GTK_WIDGET(gtk_builder_get_object(builder, "Back"));
    g_widgets->scan_btn = GTK_WIDGET(gtk_builder_get_object(builder, "Scan"));
    g_widgets->terminal_file_view = GTK_WIDGET(gtk_builder_get_object(builder, "TerminalFileTreeView"));
    g_widgets->pcl_status_text = GTK_WIDGET(gtk_builder_get_object(builder, "PclLabel"));
    g_widgets->folder_path_text = GTK_WIDGET(gtk_builder_get_object(builder, "FolderPath"));
    g_widgets->result_text = GTK_WIDGET(gtk_builder_get_object(builder, "ResultText"));
    g_widgets->send_file_chooser = GTK_WIDGET(gtk_builder_get_object(builder, "SendFileChooser"));
    g_widgets->download_file_chooser = GTK_WIDGET(gtk_builder_get_object(builder, "DownloadFileChooser"));
    g_widgets->scan_result_dialog = GTK_WIDGET(gtk_builder_get_object(builder, "ScanResultWin"));
    g_widgets->scan_result_box = GTK_WIDGET(gtk_builder_get_object(builder, "ScanResultBox"));
    gtk_builder_connect_signals(builder, g_widgets);

    g_object_unref(builder);

    gtk_widget_show(g_widgets->windows_main);
    //launch thread PCL state
    g_thread_new(NULL, (GThreadFunc)PclStateThread, g_widgets->pcl_status_text);

    gtk_main();

    g_slice_free(app_widgets, g_widgets);
    return 0;
}