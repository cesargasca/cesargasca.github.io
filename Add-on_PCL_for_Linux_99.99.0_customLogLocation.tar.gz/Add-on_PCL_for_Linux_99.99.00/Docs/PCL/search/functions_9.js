var searchData=
[
  ['openbarcode_428',['openBarcode',['../pda_util_8h.html#a92431b919bd5e0e5ae10c788354a90eb',1,'pdaUtil.h']]],
  ['openbarcodewithinactivity_429',['openBarcodeWithInactivity',['../pda_util_8h.html#a1c6963addc7523dbb769345941498594',1,'pdaUtil.h']]],
  ['openprinter_430',['openPrinter',['../pda_util_8h.html#a71ab67a3b0663b202567007004bf118b',1,'pdaUtil.h']]]
];
