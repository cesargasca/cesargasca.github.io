var searchData=
[
  ['t_5ffile_5fsharing_5fstate_545',['T_FILE_SHARING_STATE',['../file_sharing_8h.html#a61199477842044f96d695b44fa45467d',1,'fileSharing.h']]]
];
