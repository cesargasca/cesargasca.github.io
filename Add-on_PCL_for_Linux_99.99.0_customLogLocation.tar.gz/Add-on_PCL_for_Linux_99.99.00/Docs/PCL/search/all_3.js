var searchData=
[
  ['callbacks_5ft_95',['callbacks_t',['../structcallbacks__t.html',1,'']]],
  ['closebarcode_96',['closeBarcode',['../pda_util_8h.html#a89438f2fd76f4a94b361d8bf95ea83c0',1,'pdaUtil.h']]],
  ['closeprinter_97',['closePrinter',['../pda_util_8h.html#a8b8174de45187924f7464140129b8d8b',1,'pdaUtil.h']]],
  ['create_5fitransactionin_98',['create_itransactionin',['../pda_util_8h.html#a30a78cfcae347c0335b41d72e9c87fdc',1,'pdaUtil.h']]],
  ['create_5fitransactionout_99',['create_itransactionout',['../pda_util_8h.html#a2b100f28012a81cb5527154bbaa35516',1,'pdaUtil.h']]],
  ['current_5fssl_5fprofile_100',['current_ssl_profile',['../structtms__ssl__parameter__t.html#af71c556bd365b03b0a2f80c9416a8a48',1,'tms_ssl_parameter_t']]],
  ['cutpaperfunc_101',['CutPaperFunc',['../pda_util_8h.html#a36473ddfcc964edb4fac742802226be8',1,'pdaUtil.h']]]
];
