var searchData=
[
  ['cutpaperfunc_514',['CutPaperFunc',['../pda_util_8h.html#a36473ddfcc964edb4fac742802226be8',1,'pdaUtil.h']]]
];
