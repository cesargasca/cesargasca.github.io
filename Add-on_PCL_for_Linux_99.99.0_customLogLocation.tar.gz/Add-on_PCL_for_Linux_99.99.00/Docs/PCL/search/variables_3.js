var searchData=
[
  ['factivated_478',['fActivated',['../struct___u_s_b___c_o_m_p_a_n_i_o_n___i_n_f_o.html#ad99d386ea09b925c4a5e7251a7d5766c',1,'_USB_COMPANION_INFO::fActivated()'],['../struct___i_p___c_o_m_p_a_n_i_o_n___i_n_f_o.html#ad99d386ea09b925c4a5e7251a7d5766c',1,'_IP_COMPANION_INFO::fActivated()']]]
];
