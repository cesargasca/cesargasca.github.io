var searchData=
[
  ['receivemessage_297',['receiveMessage',['../pda_util_8h.html#ac1bd3466bf06436a4abea40a3d324e45',1,'pdaUtil.h']]],
  ['registerbarcodeeventcallback_298',['registerBarcodeEventCallback',['../pda_util_8h.html#abb0972927e5ea9e898313f140dad4e40',1,'pdaUtil.h']]],
  ['registerbarcodeeventextcallback_299',['registerBarcodeEventExtCallback',['../pda_util_8h.html#ac577f563128a1d9660138ebcfd1c2edd',1,'pdaUtil.h']]],
  ['registercallback_300',['registerCallback',['../pda_util_8h.html#a2da7b08102989e635765bf222fbfaf19',1,'pdaUtil.h']]],
  ['registersigncapcallback_301',['registerSignCapCallback',['../pda_util_8h.html#a6f9a1538e93796e035b23dd355a5aa4e',1,'pdaUtil.h']]],
  ['resetterminal_302',['resetTerminal',['../pda_util_8h.html#ac54dab14a0794e7dedb2137935f043a2',1,'pdaUtil.h']]]
];
