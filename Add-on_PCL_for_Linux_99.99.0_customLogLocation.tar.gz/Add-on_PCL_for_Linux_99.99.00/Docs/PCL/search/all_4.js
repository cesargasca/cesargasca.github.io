var searchData=
[
  ['dotransaction_102',['doTransaction',['../pda_util_8h.html#ae9fbf1fcc181e04fd4744c4dbed09877',1,'pdaUtil.h']]],
  ['dotransactionex_103',['doTransactionEx',['../pda_util_8h.html#a44a86887cc8d554b35daab9a6e5692ca',1,'pdaUtil.h']]],
  ['doupdate_104',['doUpdate',['../pda_util_8h.html#ab76c72294c51c451eb0c9b77992beba8',1,'pdaUtil.h']]],
  ['dword_105',['DWORD',['../_pcl_utilities_8h.html#a798af1e30bc65f319c1a246cecf59e39',1,'DWORD():&#160;PclUtilities.h'],['../pda_util_8h.html#a798af1e30bc65f319c1a246cecf59e39',1,'DWORD():&#160;pdaUtil.h']]],
  ['dwproductnumber_106',['dwProductNumber',['../structspm_info__t.html#aae9f9003a48b1740ec251092a28eca71',1,'spmInfo_t']]],
  ['dwserialnumber_107',['dwSerialNumber',['../structspm_info__t.html#a619b72b1df69e0a5f2f7541eca6a7d13',1,'spmInfo_t']]]
];
