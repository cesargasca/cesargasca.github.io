var searchData=
[
  ['closebarcode_394',['closeBarcode',['../pda_util_8h.html#a89438f2fd76f4a94b361d8bf95ea83c0',1,'pdaUtil.h']]],
  ['closeprinter_395',['closePrinter',['../pda_util_8h.html#a8b8174de45187924f7464140129b8d8b',1,'pdaUtil.h']]],
  ['create_5fitransactionin_396',['create_itransactionin',['../pda_util_8h.html#a30a78cfcae347c0335b41d72e9c87fdc',1,'pdaUtil.h']]],
  ['create_5fitransactionout_397',['create_itransactionout',['../pda_util_8h.html#a2b100f28012a81cb5527154bbaa35516',1,'pdaUtil.h']]]
];
