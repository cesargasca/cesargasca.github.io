var searchData=
[
  ['pclfilesharingondownload_521',['PCLFileSharingOnDownload',['../file_sharing_8h.html#a34c430db75211c3f1808d3472e405c85',1,'fileSharing.h']]],
  ['pclfilesharingonlist_522',['PCLFileSharingOnList',['../file_sharing_8h.html#ae6054b8759d451592d342be0826b9dff',1,'fileSharing.h']]],
  ['pclfilesharingonstart_523',['PCLFileSharingOnStart',['../file_sharing_8h.html#a8b07663a26a337d181b71e294b0b4ecc',1,'fileSharing.h']]],
  ['pclfilesharingonstop_524',['PCLFileSharingOnStop',['../file_sharing_8h.html#a344b7a34035faac3a33eda43d5f1966f',1,'fileSharing.h']]],
  ['pclfilesharingonupload_525',['PCLFileSharingOnUpload',['../file_sharing_8h.html#a3d6f776fe9561a7c72027f1c6edfeefe',1,'fileSharing.h']]],
  ['pclfilesharingonuploads_526',['PCLFileSharingOnUploads',['../file_sharing_8h.html#a60a00f62feb48b88933652c7fe043296',1,'fileSharing.h']]],
  ['pip_5fcompanion_5finfo_527',['PIP_COMPANION_INFO',['../_pcl_utilities_8h.html#a2fc9e34f5b7ad9d9cf1c877615a4c1c9',1,'PclUtilities.h']]],
  ['printimagefunc_528',['PrintImageFunc',['../pda_util_8h.html#a911731c22b1192952ef90accdf9cc5ec',1,'pdaUtil.h']]],
  ['printtextfunc_529',['PrintTextFunc',['../pda_util_8h.html#a48571a8c637761b16123c7b99392a245',1,'pdaUtil.h']]],
  ['pusb_5fcompanion_5finfo_530',['PUSB_COMPANION_INFO',['../_pcl_utilities_8h.html#a0de1ad3a7daa90e9a011ab3fb2572762',1,'PclUtilities.h']]]
];
