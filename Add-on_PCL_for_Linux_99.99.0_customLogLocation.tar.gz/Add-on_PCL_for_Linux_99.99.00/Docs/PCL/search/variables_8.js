var searchData=
[
  ['usessl_499',['UseSsl',['../struct___i_p___c_o_m_p_a_n_i_o_n___i_n_f_o.html#a36c2e11558b8afa6067be80ff76b22c2',1,'_IP_COMPANION_INFO']]]
];
