var searchData=
[
  ['spminfo_5ft_363',['spmInfo_t',['../structspm_info__t.html',1,'']]]
];
