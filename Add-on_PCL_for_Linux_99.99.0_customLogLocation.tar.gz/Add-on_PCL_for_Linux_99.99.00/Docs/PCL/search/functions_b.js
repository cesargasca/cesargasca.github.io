var searchData=
[
  ['receivemessage_446',['receiveMessage',['../pda_util_8h.html#ac1bd3466bf06436a4abea40a3d324e45',1,'pdaUtil.h']]],
  ['registerbarcodeeventcallback_447',['registerBarcodeEventCallback',['../pda_util_8h.html#abb0972927e5ea9e898313f140dad4e40',1,'pdaUtil.h']]],
  ['registerbarcodeeventextcallback_448',['registerBarcodeEventExtCallback',['../pda_util_8h.html#ac577f563128a1d9660138ebcfd1c2edd',1,'pdaUtil.h']]],
  ['registercallback_449',['registerCallback',['../pda_util_8h.html#a2da7b08102989e635765bf222fbfaf19',1,'pdaUtil.h']]],
  ['registersigncapcallback_450',['registerSignCapCallback',['../pda_util_8h.html#a6f9a1538e93796e035b23dd355a5aa4e',1,'pdaUtil.h']]],
  ['resetterminal_451',['resetTerminal',['../pda_util_8h.html#ac54dab14a0794e7dedb2137935f043a2',1,'pdaUtil.h']]]
];
