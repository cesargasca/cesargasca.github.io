var searchData=
[
  ['mainpage_2etxt_367',['mainpage.txt',['../mainpage_8txt.html',1,'']]]
];
