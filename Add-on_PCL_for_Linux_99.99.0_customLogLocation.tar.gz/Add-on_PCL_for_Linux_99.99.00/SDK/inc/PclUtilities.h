#ifndef PCLUTILITIES_H_
#define PCLUTILITIES_H_

#ifdef __cplusplus
extern "C"{
#endif

typedef unsigned int	DWORD;
typedef int				BOOL;

/** Max name size*/
#define MAX_NAME_SIZE	248
/** Max ip address size*/
#define ADDRESS_IP_SIZE	20
/** Max port size*/
#define PORT_SIZE		16

/** No error */
#define SUCCESS 1
/** Error name is null*/
#define ERROR_NAME_IS_NULL 0
/** Error not enough memory*/
#define ERROR_NOT_ENOUGH_MEMORY 2
/** Error during read serial port*/
#define ERROR_UNABLE_TO_READ_COM_PORT 3
/** Error nothing to read on serial port*/
#define ERROR_READ_NOTHING 4
/** Error during read configuration file*/
#define ERROR_UNABLE_TO_READ_PROPERTIES_FILE 5
/** Error during write configuration file*/
#define ERROR_UNABLE_TO_WRITE_PROPERTIES_FILE 6
/** Error during receive IP terminal*/
#define ERROR_PCL_UTIL_IP_RECV_ERROR		7
/** Error if API not implemented */
#define ERROR_NOT_IMPLEMENTED 8
/** Error can't open serial port */
#define ERROR_UNABLE_TO_OPEN_COM_PORT 9
/** Error can't write on serial port */
#define ERROR_WRITE_NOTHING 10
/** Error read inconsistent data */
#define ERROR_READ_INCONSISTENT 11
/** Error unable to allocate resources */
#define ERROR_INTERNAL_MEMORY 12

/*! \def TYPE_USB */
#define TYPE_USB		0
/*! \def TYPE_BLUETOOTH */
#define TYPE_BLUETOOTH	1
/*! \def TYPE_RS232 */
#define TYPE_RS232		2
/*! \def TYPE_IP */
#define TYPE_IP			3

/** The USB_COMPANION_INFO structure provides information about a USB terminal. */
typedef struct _USB_COMPANION_INFO {

    char szPort[PORT_SIZE];		/**< COM port used by the terminal */
    BOOL fActivated;			/**< Specifies whether the terminal is activated. */
    char szName[MAX_NAME_SIZE];	/**< Name of the terminal (terminal type-serial number, eg. "iCT250-12345678") */
    char szSymbPort[PORT_SIZE];	/**< Optional: Symbolic COM port used by the terminal */

} USB_COMPANION_INFO;

typedef USB_COMPANION_INFO * PUSB_COMPANION_INFO;

/** The IP_COMPANION_INFO structure provides information about a IP terminal. */
typedef struct _IP_COMPANION_INFO {

	char	AdressIP[ADDRESS_IP_SIZE];		/**< IP adresse used by the terminal */
	char	AdressMAC[ADDRESS_IP_SIZE];		/**< MAC adresse of the terminal */
	BOOL    fActivated;						/**< Specifies whether the terminal is activated. */
	char    szName[MAX_NAME_SIZE];			/**< Name of the terminal (terminal type-serial number, eg. "iCT250-12345678") */
	BOOL	UseSsl;							/**< Boolean to use ssl connection*/
} IP_COMPANION_INFO;

typedef IP_COMPANION_INFO * PIP_COMPANION_INFO;

/** activate terminal com on USB.

 @param [in,out] pCom Null-terminated string containing the COM port of the
					  terminal to be paired (e.g. ttyACM0)
 @return 1 in case of success and error code in case of failure.
		  Possible error codes are Linux system error codes or the following specific PCL error codes:
		  ERROR_UNABLE_TO_WRITE_PROPERTIES_FILE  COM port can't be write in properties file. This may be due to issue during creation of directory in home.
		  ERROR_NAME_IS_NULL	Name of terminal is null. This may be due to trace activated or no terminal on some port.
		  ERROR_UNABLE_TO_READ_COM_PORT This may be due to port which is doesn't mounted.
		  ERROR_READ_NOTHING This may be due to port which is doesn't mounted.
		  */
int activateUSBDevice(char* pCom);

/** Retrieves the list of Usb Ingenico terminals connected on the Linux device.

 @param pCompanions		    Buffer containing the list of companions plugged in the Linux device
 @param [in,out] pdwSize    Size of pCompanions buffer as input. Required size as output.
 @param [in,out] pdwEntries Number of USB_COMPANION_INFO entries returned in pCompanions

 @return SUCCESS is returned in case of success and pCompanions contains the list of plugged companions. The number of companions in this list is indicated by *pdwEntries.
	     ERROR_NOT_ENOUGH_MEMORY is returned if pCompanions is NULL or if its size is not large enough to contain all the plugged companions,  *pdwSize contains the size of the buffer to be allocated.
		 If *pdwSize equals zero it means that no terminal is plugged.. */
DWORD getUSBDevices(PUSB_COMPANION_INFO pCompanions, DWORD* pdwSize, DWORD* pdwEntries);

/** Retrieves the list of Rs232 Ingenico terminal connected on the Linux device.

	@param pCompanions		    Buffer containing the list of companions plugged in the Linux device
	@param [in,out] pdwSize    Size of pCompanions buffer as input. Required size as output.
	@param [in,out] pdwEntries Number of USB_COMPANION_INFO entries returned in pCompanions

	@return SUCCESS is returned in case of success and pCompanions contains the list of plugged companions. The number of companions in this list is indicated by *pdwEntries.
		ERROR_NOT_ENOUGH_MEMORY is returned if pCompanions is NULL or if its size is not large enough to contain all the plugged companions,  *pdwSize contains the size of the buffer to be allocated.
		If *pdwSize equals zero it means that no terminal is plugged.. */
DWORD getRS232Devices(PUSB_COMPANION_INFO pCompanions, DWORD* pdwSize, DWORD* pdwEntries);

/** Activate a Rs232 terminal plugged on the Linux device.
 @param [in,out] pCom Null-terminated string containing the COM port of the
					  terminal to be paired.
 	@return SUCCESS in case of success or error code in case of failure.
		Possible error codes are Linux system error codes or the following specific PCL error codes:
		ERROR_UNABLE_TO_WRITE_PROPERTIES_FILE  COM port can't be write in properties file. This may be due to issue during creation of directory in home.
		  ERROR_NAME_IS_NULL	Name of terminal is null. This may be due to trace activated or no terminal on some port.
		  ERROR_UNABLE_TO_READ_COM_PORT This may be due to port which is doesn't mounted.
		  ERROR_READ_NOTHING This may be due to port which is doesn't mounted.*/
int activateRS232Device(char* pCom);

/** Retrieves the list of IP Ingenico companions on the same network of the Windows device.
@param pCompanions		   Buffer containing the list of companions on the same network of the Windows device.
@param [in,out] pdwSize    Size of pCompanions buffer as input. Required size as output.
@param [in,out] pdwEntries Number of IP_COMPANION_INFO entries returned in pCompanions
@return SUCCESS is returned in case of success and pCompanions contains the list of plugged companions. The number of companions in this list is indicated by *pdwEntries. */
DWORD getIPDevices(PIP_COMPANION_INFO pCompanions, DWORD* pdwSize, DWORD* pdwEntries);

/** Activate a IP terminal plugged on the Windows device.
@param [in] pIPDevice Structure containing the IP terminal to be paired.
@return SUCCESS in case of success or error code in case of failure.*/
int activateIPDevice(PIP_COMPANION_INFO pIPDevice);

/** Get activated terminal name and connection type.
	@param	szName		A pointer to a buffer that receives the terminal name.
	@param	dwNameSize	Size of the buffer pointed to by the szName parameter, in bytes.
	@param	pdwType		A pointer to a DWORD to receive connection type
	@return SUCCESS in case of success, else error code as following
	ERROR_UNABLE_TO_READ_PROPERTIES_FILE  COM port can't be read in properties file. This may be due to issue during creation of directory in home.	*/
int getActivatedDevice(char* szName, DWORD dwNameSize, DWORD* pdwType);

/** Add Authorized USB Vid/Pid
* @param  pVid USB Vid
* @param  pPid USB Pid
* @return SUCCESS in case of success, else error
* @note by default authorized :
* (0x079B, 0x0028), (0x0B00, 0x0052), (0x0B00, 0x0053), (0x0B00, 0x0054), (0x0B00, 0x0055), (0x0B00, 0x0056), (0x0B00, 0x0057),  (0x0B00, 0x0060), (0x0B00, 0x0061),
* (0x0B00, 0x0062), (0x0B00, 0x0063), (0x0B00, 0x0064), (0x0B00, 0x0066), (0x0B00, 0x0080), (0x0B00, 0x0081), (0x0B00, 0x0082), (0x0B00, 0x0083), (0x0B00, 0x0084),
* (0x0B00, 0x0085), (0x0B00, 0x0087), (0x0B00, 0x0088), (0x0B00, 0x0095), (0x0B00, 0x0096), (0x0B00, 0x0098), (0x0B00, 0x0099)*/
int addAuthorizedVidPid(unsigned short pVid, unsigned short pPid);

/** Set path for PclUtilities Log File.
	@param	path		new path.
	@param	size		size of path buffer.
	@return TRUE if updated , reset to /tmp/PCLUtilities.txt if FALSE */
BOOL setPclUtilitiesLogPath(const char* path, int size);

#ifdef __cplusplus
}
#endif
#endif /* PCLUTILITIES_H_ */
